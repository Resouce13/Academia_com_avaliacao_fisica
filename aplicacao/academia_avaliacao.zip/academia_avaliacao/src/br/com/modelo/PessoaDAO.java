package br.com.modelo;

import br.com.controle.Pessoa;
import br.com.controle.PessoaCombo;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.sql.SQLException;

public class PessoaDAO extends DAO {

    // Cadastra uma pessoa e sua especialização como aluno
    public int cadastrarAluno(
            Pessoa pessoa,
            String matricula,
            String status) throws Exception {

        try {
            abrirBanco();
            con.setAutoCommit(false);

            int idPessoa = inserirPessoa(pessoa);

            String sql
                    = "INSERT INTO aluno "
                    + "(id_pessoa, matricula, status_matricula) "
                    + "VALUES (?, ?, ?)";

            try (PreparedStatement stmt = con.prepareStatement(sql)) {
                stmt.setInt(1, idPessoa);
                stmt.setString(2, matricula);
                stmt.setString(3, status);
                stmt.executeUpdate();
            }

            con.commit();

            pessoa.setIdPessoa(idPessoa);
            return idPessoa;

        } catch (Exception e) {
            reverterTransacao(e);
            throw tratarErro(e);
        } finally {
            fecharTransacao();
        }
    }

    // Cadastra uma pessoa e sua especialização como profissional
    public int cadastrarProfissional(
            Pessoa pessoa,
            String registro,
            String especialidade,
            Integer idSupervisor) throws Exception {

        try {
            abrirBanco();
            con.setAutoCommit(false);

            int idPessoa = inserirPessoa(pessoa);

            String sql
                    = "INSERT INTO profissional "
                    + "(id_pessoa, registro_profissional, "
                    + "especialidade, id_supervisor) "
                    + "VALUES (?, ?, ?, ?)";

            try (PreparedStatement stmt = con.prepareStatement(sql)) {
                stmt.setInt(1, idPessoa);
                stmt.setString(2, registro);
                stmt.setString(3, especialidade);

                if (idSupervisor == null) {
                    stmt.setNull(4, Types.INTEGER);
                } else {
                    stmt.setInt(4, idSupervisor);
                }

                stmt.executeUpdate();
            }

            con.commit();

            pessoa.setIdPessoa(idPessoa);
            return idPessoa;

        } catch (Exception e) {
            reverterTransacao(e);
            throw tratarErro(e);
        } finally {
            fecharTransacao();
        }
    }

    // Insere a pessoa e recupera o ID gerado pelo MySQL
    private int inserirPessoa(Pessoa pessoa) throws Exception {

        String sql
                = "INSERT INTO pessoa "
                + "(nome, cpf, data_nascimento, telefone, email, "
                + "rua, numero, bairro, cidade, uf, cep) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement stmt = con.prepareStatement(
                sql, PreparedStatement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, pessoa.getNome());
            stmt.setString(2, pessoa.getCpf());
            stmt.setString(3, pessoa.getDataNascimento());

            if (pessoa.getTelefone() == null
                    || pessoa.getTelefone().trim().isEmpty()) {
                stmt.setNull(4, Types.VARCHAR);
            } else {
                stmt.setString(4, pessoa.getTelefone());
            }

            if (pessoa.getEmail() == null
                    || pessoa.getEmail().trim().isEmpty()) {
                stmt.setNull(5, Types.VARCHAR);
            } else {
                stmt.setString(5, pessoa.getEmail());
            }

            stmt.setString(6, pessoa.getRua());
            stmt.setString(7, pessoa.getNumero());
            stmt.setString(8, pessoa.getBairro());
            stmt.setString(9, pessoa.getCidade());
            stmt.setString(10, pessoa.getUf());
            stmt.setString(11, pessoa.getCep());

            stmt.executeUpdate();

            try (ResultSet rs = stmt.getGeneratedKeys()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        }

        throw new Exception("O banco não retornou o ID da pessoa.");
    }

    // Desfaz as alterações se alguma operação falhar
    private void reverterTransacao(Exception erroOriginal) {
        if (con != null) {
            try {
                con.rollback();
            } catch (Exception erroRollback) {
                erroOriginal.addSuppressed(erroRollback);
            }
        }
    }

    // Restaura a conexão e fecha o banco
    private void fecharTransacao() throws Exception {
        if (con != null) {
            try {
                con.setAutoCommit(true);
            } finally {
                fecharBanco();
            }
        }
    }

    // Consulta uma pessoa pelo CPF e identifica se é aluno ou profissional
    public java.util.Map<String, Object> consultarPorCpf(String cpf)
            throws Exception {

        String sql
                = "SELECT p.id_pessoa, p.nome, p.cpf, "
                + "p.data_nascimento, p.telefone, p.email, "
                + "p.rua, p.numero, p.bairro, p.cidade, p.uf, p.cep, "
                + "a.matricula, a.status_matricula, "
                + "pr.registro_profissional, pr.especialidade, "
                + "pr.id_supervisor, "
                + "CASE "
                + "WHEN a.id_pessoa IS NOT NULL THEN 'aluno' "
                + "WHEN pr.id_pessoa IS NOT NULL THEN 'profissional' "
                + "ELSE 'não definido' END AS tipo "
                + "FROM pessoa p "
                + "LEFT JOIN aluno a ON a.id_pessoa = p.id_pessoa "
                + "LEFT JOIN profissional pr ON pr.id_pessoa = p.id_pessoa "
                + "WHERE p.cpf = ?";

        try {
            abrirBanco();

            try (PreparedStatement stmt = con.prepareStatement(sql)) {
                stmt.setString(1, cpf);

                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        java.util.Map<String, Object> dados
                                = new java.util.HashMap<>();

                        dados.put("id_pessoa", rs.getInt("id_pessoa"));
                        dados.put("nome", rs.getString("nome"));
                        dados.put("cpf", rs.getString("cpf"));
                        dados.put("data_nascimento",
                                rs.getString("data_nascimento"));
                        dados.put("telefone", rs.getString("telefone"));
                        dados.put("email", rs.getString("email"));
                        dados.put("rua", rs.getString("rua"));
                        dados.put("numero", rs.getString("numero"));
                        dados.put("bairro", rs.getString("bairro"));
                        dados.put("cidade", rs.getString("cidade"));
                        dados.put("uf", rs.getString("uf"));
                        dados.put("cep", rs.getString("cep"));

                        dados.put("matricula", rs.getString("matricula"));
                        dados.put("status_matricula",
                                rs.getString("status_matricula"));

                        dados.put("registro_profissional",
                                rs.getString("registro_profissional"));
                        dados.put("especialidade",
                                rs.getString("especialidade"));

                        int supervisor = rs.getInt("id_supervisor");
                        dados.put("id_supervisor",
                                rs.wasNull() ? null : supervisor);

                        dados.put("tipo", rs.getString("tipo"));

                        return dados;
                    }
                }
            }

            return null;

        } finally {
            fecharBanco();
        }
    }

    // Altera os dados de uma pessoa já cadastrada
    public void alterarPessoa(
            Pessoa pessoa,
            String matricula,
            String status,
            String registro,
            String especialidade,
            Integer idSupervisor) throws Exception {

        try {
            abrirBanco();
            con.setAutoCommit(false);

            // Confere qual tipo está cadastrado para essa pessoa
            String tipoCadastrado = null;

            String sqlTipo
                    = "SELECT "
                    + "CASE "
                    + "WHEN EXISTS (SELECT 1 FROM aluno "
                    + "WHERE id_pessoa = p.id_pessoa) THEN 'aluno' "
                    + "WHEN EXISTS (SELECT 1 FROM profissional "
                    + "WHERE id_pessoa = p.id_pessoa) "
                    + "THEN 'profissional' "
                    + "ELSE 'não definido' END AS tipo "
                    + "FROM pessoa p WHERE p.id_pessoa = ?";

            try (PreparedStatement stmt = con.prepareStatement(sqlTipo)) {
                stmt.setInt(1, pessoa.getIdPessoa());

                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        tipoCadastrado = rs.getString("tipo");
                    }
                }
            }

            if (tipoCadastrado == null) {
                throw new Exception("Pessoa não encontrada no banco.");
            }

            // Atualiza os dados pessoais
            String sqlPessoa
                    = "UPDATE pessoa SET nome = ?, cpf = ?, "
                    + "data_nascimento = ?, telefone = ?, email = ?, "
                    + "rua = ?, numero = ?, bairro = ?, cidade = ?, "
                    + "uf = ?, cep = ? WHERE id_pessoa = ?";

            try (PreparedStatement stmt = con.prepareStatement(sqlPessoa)) {
                stmt.setString(1, pessoa.getNome());
                stmt.setString(2, pessoa.getCpf());
                stmt.setString(3, pessoa.getDataNascimento());

                if (pessoa.getTelefone() == null
                        || pessoa.getTelefone().trim().isEmpty()) {
                    stmt.setNull(4, Types.VARCHAR);
                } else {
                    stmt.setString(4, pessoa.getTelefone());
                }

                if (pessoa.getEmail() == null
                        || pessoa.getEmail().trim().isEmpty()) {
                    stmt.setNull(5, Types.VARCHAR);
                } else {
                    stmt.setString(5, pessoa.getEmail());
                }

                stmt.setString(6, pessoa.getRua());
                stmt.setString(7, pessoa.getNumero());
                stmt.setString(8, pessoa.getBairro());
                stmt.setString(9, pessoa.getCidade());
                stmt.setString(10, pessoa.getUf());
                stmt.setString(11, pessoa.getCep());
                stmt.setInt(12, pessoa.getIdPessoa());

                stmt.executeUpdate();
            }

            // Atualiza somente a especialização que já existe
            if ("aluno".equals(tipoCadastrado)) {
                String sqlAluno
                        = "UPDATE aluno SET matricula = ?, "
                        + "status_matricula = ? WHERE id_pessoa = ?";

                try (PreparedStatement stmt = con.prepareStatement(sqlAluno)) {
                    stmt.setString(1, matricula);
                    stmt.setString(2, status);
                    stmt.setInt(3, pessoa.getIdPessoa());

                    if (stmt.executeUpdate() == 0) {
                        throw new Exception("Não foi possível alterar o aluno.");
                    }
                }

            } else if ("profissional".equals(tipoCadastrado)) {
                String sqlProfissional
                        = "UPDATE profissional SET registro_profissional = ?, "
                        + "especialidade = ?, id_supervisor = ? "
                        + "WHERE id_pessoa = ?";

                try (PreparedStatement stmt
                        = con.prepareStatement(sqlProfissional)) {

                    stmt.setString(1, registro);
                    stmt.setString(2, especialidade);

                    if (idSupervisor == null) {
                        stmt.setNull(3, Types.INTEGER);
                    } else {
                        stmt.setInt(3, idSupervisor);
                    }

                    stmt.setInt(4, pessoa.getIdPessoa());

                    if (stmt.executeUpdate() == 0) {
                        throw new Exception(
                                "Não foi possível alterar o profissional.");
                    }
                }

            } else {
                throw new Exception(
                        "A pessoa não está cadastrada como aluno "
                        + "nem como profissional.");
            }

            con.commit();

        } catch (Exception e) {
            reverterTransacao(e);
            throw tratarErro(e);
        } finally {
            fecharTransacao();
        }
    }

    // Exclui uma pessoa e seu registro de aluno ou profissional
    public void excluirPessoa(int idPessoa) throws Exception {
        try {
            abrirBanco();
            con.setAutoCommit(false);

            // Verifica se a pessoa existe
            String sqlVerificar
                    = "SELECT id_pessoa FROM pessoa WHERE id_pessoa = ?";

            try (PreparedStatement stmt
                    = con.prepareStatement(sqlVerificar)) {
                stmt.setInt(1, idPessoa);

                try (ResultSet rs = stmt.executeQuery()) {
                    if (!rs.next()) {
                        throw new Exception(
                                "Pessoa não encontrada no banco.");
                    }
                }
            }

            // Exclui o registro de aluno, caso exista
            String sqlAluno
                    = "DELETE FROM aluno WHERE id_pessoa = ?";

            try (PreparedStatement stmt = con.prepareStatement(sqlAluno)) {
                stmt.setInt(1, idPessoa);
                stmt.executeUpdate();
            }

            // Exclui o registro de profissional, caso exista
            String sqlProfissional
                    = "DELETE FROM profissional WHERE id_pessoa = ?";

            try (PreparedStatement stmt
                    = con.prepareStatement(sqlProfissional)) {
                stmt.setInt(1, idPessoa);
                stmt.executeUpdate();
            }

            // Exclui a pessoa
            String sqlPessoa
                    = "DELETE FROM pessoa WHERE id_pessoa = ?";

            try (PreparedStatement stmt = con.prepareStatement(sqlPessoa)) {
                stmt.setInt(1, idPessoa);
                stmt.executeUpdate();
            }

            con.commit();

        } catch (Exception e) {
            reverterTransacao(e);
            throw tratarErro(e);
        } finally {
            fecharTransacao();
        }
    }

    private Exception tratarErro(Exception e) {
        if (e instanceof java.sql.SQLException) {
            java.sql.SQLException erroSQL
                    = (java.sql.SQLException) e;

            String codigo = erroSQL.getSQLState();
            int numero = erroSQL.getErrorCode();

            if (numero == 1062) {
                return new Exception(
                        "Este CPF, matrícula ou registro "
                        + "já está cadastrado.");
            }

            if (numero == 1452) {
                return new Exception(
                        "Não foi possível realizar a operação. "
                        + "Verifique se os registros relacionados existem.");
            }

            if (numero == 1451) {
                return new Exception(
                        "Não é possível excluir este registro porque "
                        + "existem outros registros vinculados a ele.");
            }

            if ("23000".equals(codigo)) {
                return new Exception(
                        "A operação viola uma restrição do banco. "
                        + "Verifique os dados informados.");
            }
        }

        return new Exception(
                "Não foi possível concluir a operação. "
                + "Verifique os dados e tente novamente.");
    }

    public ArrayList<PessoaCombo> listarPessoasDisponiveisParaAluno()
            throws SQLException, Exception {

        ArrayList<PessoaCombo> lista = new ArrayList<>();

        String sql
                = "SELECT p.id_pessoa, p.nome "
                + "FROM pessoa p "
                + "LEFT JOIN aluno a ON p.id_pessoa = a.id_pessoa "
                + "WHERE a.id_pessoa IS NULL "
                + "ORDER BY p.nome";

        try {
            abrirBanco();

            pst = con.prepareStatement(sql);
            rs = pst.executeQuery();

            while (rs.next()) {
                PessoaCombo pessoa = new PessoaCombo(
                        rs.getInt("id_pessoa"),
                        rs.getString("nome")
                );

                lista.add(pessoa);
            }

        } finally {
            fecharBanco();
        }

        return lista;
    }

    public void cadastrarAlunoExistente(
            int idPessoa, String matricula, String status)
            throws SQLException, Exception {

        String sql
                = "INSERT INTO aluno (id_pessoa, matricula, status_matricula) "
                + "VALUES (?, ?, ?)";

        try {
            abrirBanco();

            pst = con.prepareStatement(sql);
            pst.setInt(1, idPessoa);
            pst.setString(2, matricula);
            pst.setString(3, status);

            pst.executeUpdate();

        } finally {
            fecharBanco();
        }
    }

    public void cadastrarProfissionalExistente(
            int idPessoa,
            String registro,
            String especialidade,
            Integer idSupervisor) throws Exception {

        String sql
                = "INSERT INTO profissional "
                + "(id_pessoa, registro_profissional, "
                + "especialidade, id_supervisor) "
                + "VALUES (?, ?, ?, ?)";

        try {
            abrirBanco();

            pst = con.prepareStatement(sql);
            pst.setInt(1, idPessoa);
            pst.setString(2, registro);
            pst.setString(3, especialidade);

            if (idSupervisor == null) {
                pst.setNull(4, java.sql.Types.INTEGER);
            } else {
                pst.setInt(4, idSupervisor);
            }

            pst.executeUpdate();

        } finally {
            fecharBanco();
        }
    }

    public ArrayList<PessoaCombo> listarPessoasDisponiveisParaProfissional()
            throws Exception {

        ArrayList<PessoaCombo> lista = new ArrayList<>();

        String sql = "SELECT p.id_pessoa, p.nome "
                + "FROM pessoa p "
                + "LEFT JOIN profissional pr ON p.id_pessoa = pr.id_pessoa "
                + "WHERE pr.id_pessoa IS NULL "
                + "ORDER BY p.nome";

        try {
            abrirBanco();
            pst = con.prepareStatement(sql);
            rs = pst.executeQuery();

            while (rs.next()) {
                PessoaCombo pessoa = new PessoaCombo(
                        rs.getInt("id_pessoa"),
                        rs.getString("nome")
                );

                lista.add(pessoa);
            }

        } finally {
            fecharBanco();
        }

        return lista;
    }
}
