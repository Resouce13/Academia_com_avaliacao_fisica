package br.com.modelo;

import java.security.GeneralSecurityException;
import java.security.SecureRandom;
import java.util.Base64;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/** Exemplo de derivação e verificação de senha com PBKDF2-HMAC-SHA256. */
public final class SenhaUtil {
    private static final int ITERACOES = 210_000;
    private static final int TAMANHO_SAL_BYTES = 16;
    private static final int TAMANHO_HASH_BITS = 256;
    private static final SecureRandom RANDOM = new SecureRandom();

    private SenhaUtil() {}

    public static String gerarSalBase64() {
        byte[] sal = new byte[TAMANHO_SAL_BYTES];
        RANDOM.nextBytes(sal);
        return Base64.getEncoder().encodeToString(sal);
    }

    public static String gerarHash(String senha, String salBase64)
            throws GeneralSecurityException {
        byte[] sal = Base64.getDecoder().decode(salBase64);
        PBEKeySpec spec = new PBEKeySpec(
                senha.toCharArray(), sal, ITERACOES, TAMANHO_HASH_BITS);
        try {
            SecretKeyFactory fabrica =
                    SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
            return Base64.getEncoder().encodeToString(
                    fabrica.generateSecret(spec).getEncoded());
        } finally {
            spec.clearPassword();
        }
    }

    public static boolean verificarSenha(
            String senhaInformada, String salBase64, String hashArmazenado)
            throws GeneralSecurityException {
        byte[] esperado = Base64.getDecoder().decode(hashArmazenado);
        byte[] obtido = Base64.getDecoder().decode(
                gerarHash(senhaInformada, salBase64));
        if (esperado.length != obtido.length) return false;
        int diferenca = 0;
        for (int i = 0; i < esperado.length; i++) {
            diferenca |= esperado[i] ^ obtido[i];
        }
        return diferenca == 0;
    }
}
