
package br.com.modelo;

import java.sql.SQLException;
import java.security.GeneralSecurityException;

public class UsuarioAplicacaoDAO extends DAO {

    public boolean cadastrarUsuario(
            String nomeUsuario,
            String senha,
            String perfil)
            throws SQLException, GeneralSecurityException {

        if (nomeUsuario == null || nomeUsuario.trim().isEmpty()
                || senha == null || senha.isEmpty()
                || perfil == null || perfil.trim().isEmpty()) {
            throw new IllegalArgumentException(
                "Preencha o nome de usuário, a senha e o perfil."
            );
        }

        String salt = SenhaUtil.gerarSalt();
        String hash = SenhaUtil.gerarHash(senha, salt);

        String sql = "INSERT INTO usuario_aplicacao "
                + "(nome_usuario, senha_hash, senha_salt, iteracoes, perfil) "
                + "VALUES (?, ?, ?, ?, ?)";

        try {
            abrirBanco();

            pst = con.prepareStatement(sql);
            pst.setString(1, nomeUsuario.trim());
            pst.setString(2, hash);
            pst.setString(3, salt);
            pst.setInt(4, SenhaUtil.getIteracoes());
            pst.setString(5, perfil.toUpperCase());

            return pst.executeUpdate() == 1;

        } catch (SQLException e) {
            if ("23000".equals(e.getSQLState())) {
                throw new SQLException(
                    "Não foi possível cadastrar. "
                    + "Verifique se o nome de usuário já existe "
                    + "e se o perfil é válido.",
                    e
                );
            }
            throw e;

        } finally {
            try {
                if (pst != null) {
                    pst.close();
                    pst = null;
                }
            } finally {
                if (con != null) {
                    con.close();
                    con = null;
                }
            }
        }
    }
}