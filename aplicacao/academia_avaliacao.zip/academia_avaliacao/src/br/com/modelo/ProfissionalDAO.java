package br.com.modelo;

import br.com.controle.Pessoa;
import br.com.controle.Profissional;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class ProfissionalDAO extends DAO {

    // CADASTRAR PESSOA + PROFISSIONAL
    public void inserir(Profissional p) throws Exception {

        Pessoa pessoa = p.getPessoa();

        if (pessoa == null) {
            throw new IllegalArgumentException(
                    "Os dados pessoais do profissional não foram informados."
            );
        }

        try {
            abrirBanco();
            con.setAutoCommit(false);

            // 1. Inserir os dados pessoais
            String sqlPessoa
                    = "INSERT INTO pessoa "
                    + "(nome, cpf, data_nascimento, telefone, email, "
                    + "rua, numero, bairro, cidade, uf, cep) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            try (PreparedStatement stmt = con.prepareStatement(
                    sqlPessoa, PreparedStatement.RETURN_GENERATED_KEYS)) {

                stmt.setString(1, pessoa.getNome());
                stmt.setString(2, pessoa.getCpf());
                stmt.setString(3, pessoa.getDataNascimento());

                if (pessoa.getTelefone() == null
                        || pessoa.getTelefone().trim().isEmpty()) {
                    stmt.setNull(4, java.sql.Types.VARCHAR);
                } else {
                    stmt.setString(4, pessoa.getTelefone());
                }

                if (pessoa.getEmail() == null
                        || pessoa.getEmail().trim().isEmpty()) {
                    stmt.setNull(5, java.sql.Types.VARCHAR);
                } else {
                    stmt.setString(5, pessoa.getEmail());
                }

                stmt.setString(6, pessoa.getRua());
                stmt.setString(7, pessoa.getNumero());
                stmt.setString(8, pessoa.getBairro());
                stmt.setString(9, pessoa.getCidade());
                stmt.setString(10, pessoa.getUf());
                stmt.setString(11, pessoa.getCep());

                stmt.executeUpdate();

                // 2. Recuperar o ID gerado pelo MySQL
                try (ResultSet chaves = stmt.getGeneratedKeys()) {
                    if (!chaves.next()) {
                        throw new Exception(
                                "Não foi possível obter o ID da pessoa."
                        );
                    }

                    int idPessoa = chaves.getInt(1);

                    pessoa.setIdPessoa(idPessoa);
                    p.setIdPessoa(idPessoa);
                }
            }

            // 3. Inserir os dados profissionais
            String sqlProfissional
                    = "INSERT INTO profissional "
                    + "(id_pessoa, registro_profissional, "
                    + "especialidade, id_supervisor) "
                    + "VALUES (?, ?, ?, ?)";

            try (PreparedStatement stmt
                    = con.prepareStatement(sqlProfissional)) {

                stmt.setInt(1, p.getIdPessoa());
                stmt.setString(2, p.getRegistroProfissional());
                stmt.setString(3, p.getEspecialidade());

                if (p.getIdSupervisor() == 0) {
                    stmt.setNull(4, java.sql.Types.INTEGER);
                } else {
                    stmt.setInt(4, p.getIdSupervisor());
                }

                stmt.executeUpdate();
            }

            // 4. Confirmar as duas inserções
            con.commit();

        } catch (Exception e) {

            if (con != null) {
                try {
                    con.rollback();
                } catch (Exception erroRollback) {
                    e.addSuppressed(erroRollback);
                }
            }

            throw e;

        } finally {

            if (con != null) {
                try {
                    con.setAutoCommit(true);
                } finally {
                    fecharBanco();
                }
            }
        }
    }

    // CONSULTAR UM PROFISSIONAL
    public Profissional consultar(int idPessoa) throws Exception {

        Profissional p = null;

        try {
            abrirBanco();

            String sql
                    = "SELECT id_pessoa, registro_profissional, "
                    + "especialidade, id_supervisor "
                    + "FROM profissional WHERE id_pessoa = ?";

            pst = con.prepareStatement(sql);
            pst.setInt(1, idPessoa);
            rs = pst.executeQuery();

            if (rs.next()) {
                p = new Profissional();

                p.setIdPessoa(rs.getInt("id_pessoa"));
                p.setRegistroProfissional(
                        rs.getString("registro_profissional"));
                p.setEspecialidade(rs.getString("especialidade"));

                int idSupervisor = rs.getInt("id_supervisor");

                p.setIdSupervisor(
                        rs.wasNull() ? 0 : idSupervisor);
            }

        } finally {
            fecharBanco();
        }

        return p;
    }

    // LISTAR PROFISSIONAIS
    public ArrayList<Profissional> listar() throws Exception {

        ArrayList<Profissional> lista = new ArrayList<>();

        try {
            abrirBanco();

            String sql
                    = "SELECT id_pessoa, registro_profissional, "
                    + "especialidade, id_supervisor "
                    + "FROM profissional "
                    + "ORDER BY registro_profissional";

            pst = con.prepareStatement(sql);
            rs = pst.executeQuery();

            while (rs.next()) {
                Profissional p = new Profissional();

                p.setIdPessoa(rs.getInt("id_pessoa"));
                p.setRegistroProfissional(
                        rs.getString("registro_profissional"));
                p.setEspecialidade(rs.getString("especialidade"));

                int idSupervisor = rs.getInt("id_supervisor");

                p.setIdSupervisor(
                        rs.wasNull() ? 0 : idSupervisor);

                lista.add(p);
            }

        } finally {
            fecharBanco();
        }

        return lista;
    }

    // ALTERAR DADOS PROFISSIONAIS
    public void alterar(Profissional p) throws Exception {

        try {
            abrirBanco();

            String sql
                    = "UPDATE profissional "
                    + "SET registro_profissional = ?, "
                    + "especialidade = ?, id_supervisor = ? "
                    + "WHERE id_pessoa = ?";

            pst = con.prepareStatement(sql);

            pst.setString(1, p.getRegistroProfissional());
            pst.setString(2, p.getEspecialidade());

            if (p.getIdSupervisor() == 0) {
                pst.setNull(3, java.sql.Types.INTEGER);
            } else {
                pst.setInt(3, p.getIdSupervisor());
            }

            pst.setInt(4, p.getIdPessoa());

            int linhas = pst.executeUpdate();

            if (linhas == 0) {
                throw new Exception(
                        "Nenhum profissional encontrado com esse ID."
                );
            }

        } finally {
            fecharBanco();
        }
    }

    // EXCLUIR PROFISSIONAL E PESSOA NA MESMA TRANSAÇÃO
    public void excluir(int idPessoa) throws Exception {

        try {
            abrirBanco();
            con.setAutoCommit(false);

            // Primeiro exclui o registro da especialização
            String sqlProfissional
                    = "DELETE FROM profissional WHERE id_pessoa = ?";

            try (PreparedStatement stmt
                    = con.prepareStatement(sqlProfissional)) {

                stmt.setInt(1, idPessoa);

                int linhas = stmt.executeUpdate();

                if (linhas == 0) {
                    throw new Exception(
                            "Nenhum profissional encontrado com esse ID."
                    );
                }
            }

            // Depois exclui a pessoa correspondente
            String sqlPessoa
                    = "DELETE FROM pessoa WHERE id_pessoa = ?";

            try (PreparedStatement stmt
                    = con.prepareStatement(sqlPessoa)) {

                stmt.setInt(1, idPessoa);
                stmt.executeUpdate();
            }

            con.commit();

        } catch (Exception e) {

            if (con != null) {
                try {
                    con.rollback();
                } catch (Exception erroRollback) {
                    e.addSuppressed(erroRollback);
                }
            }

            throw e;

        } finally {

            if (con != null) {
                try {
                    con.setAutoCommit(true);
                } finally {
                    fecharBanco();
                }
            }
        }
    }

    // CONSULTAR PROFISSIONAIS POR REGISTRO E ESPECIALIDADE
    public ArrayList<Profissional> consultarPorFiltro(
            String registro, String especialidade) throws Exception {

        ArrayList<Profissional> lista = new ArrayList<>();

        try {
            abrirBanco();

            String sql
                    = "SELECT id_pessoa, registro_profissional, "
                    + "especialidade, id_supervisor "
                    + "FROM profissional "
                    + "WHERE registro_profissional LIKE ? "
                    + "AND especialidade LIKE ? "
                    + "ORDER BY registro_profissional";

            pst = con.prepareStatement(sql);
            pst.setString(1, "%" + registro + "%");
            pst.setString(2, "%" + especialidade + "%");

            rs = pst.executeQuery();

            while (rs.next()) {
                Profissional p = new Profissional();

                p.setIdPessoa(rs.getInt("id_pessoa"));
                p.setRegistroProfissional(
                        rs.getString("registro_profissional"));
                p.setEspecialidade(
                        rs.getString("especialidade"));

                int idSupervisor = rs.getInt("id_supervisor");
                p.setIdSupervisor(rs.wasNull() ? 0 : idSupervisor);

                lista.add(p);
            }

        } finally {
            fecharBanco();
        }

        return lista;
    }
}
