/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package br.com.visao;

import br.com.controle.Treino;
import br.com.controle.TreinoExercicio;
import br.com.modelo.TreinoDAO;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Gabriel_DEV
 */
public class CadastrarTreino extends javax.swing.JFrame {

    private void mostrarErroBanco(Exception ex) {
        String mensagem = ex.getMessage();

        if (ex instanceof java.sql.SQLException) {
            java.sql.SQLException erro = (java.sql.SQLException) ex;
            String mensagemBanco = erro.getMessage().toLowerCase();

            if (erro.getErrorCode() == 1062) {
                mensagem = "Este registro já existe no banco de dados.";
            } else if (erro.getErrorCode() == 1452) {
                mensagem = "O aluno, profissional ou exercício informado "
                        + "não existe. Confira os IDs.";
            } else if (erro.getErrorCode() == 1451) {
                mensagem = "Não é possível excluir este registro porque "
                        + "ele está sendo utilizado em outro cadastro.";
            } else if (mensagemBanco.contains("check constraint")) {
                mensagem = "Um dos valores informados não atende às "
                        + "regras do cadastro.";
            } else if (mensagemBanco.contains("cannot be null")) {
                mensagem = "Preencha todos os campos obrigatórios.";
            } else if (mensagemBanco.contains("data too long")
                    || mensagemBanco.contains("incorrect")) {
                mensagem = "Um dos valores informados está inválido. "
                        + "Confira os campos.";
            } else {
                mensagem = "Não foi possível concluir a operação. "
                        + "Confira os dados e tente novamente.";
            }
        } else {
            mensagem = "Não foi possível concluir a operação. "
                    + "Confira os dados informados.";
        }

        JOptionPane.showMessageDialog(this, mensagem,
                "Atenção", JOptionPane.WARNING_MESSAGE);
    }

    private void consultarTreinos() {
        try {
            TreinoDAO dao = new TreinoDAO();
            ArrayList<Object[]> lista;

            String idAluno = jTidAluno.getText().trim();

            if (idAluno.isEmpty()) {
                lista = dao.consultarTreinos();
            } else {
                int id = Integer.parseInt(idAluno);

                if (id <= 0) {
                    JOptionPane.showMessageDialog(this,
                            "Informe um ID de aluno válido.");
                    return;
                }

                lista = dao.consultarTreinosPorAluno(id);
            }

            DefaultTableModel modelo
                    = (DefaultTableModel) jTable2.getModel();

            modelo.setRowCount(0);

            for (Object[] treino : lista) {
                modelo.addRow(treino);
            }

            if (lista.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "Nenhum treino encontrado para essa consulta.");
            }

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this,
                    "O ID do aluno deve conter apenas números.");

        } catch (Exception ex) {
            ex.printStackTrace();

            JOptionPane.showMessageDialog(this,
                    "Erro ao consultar treinos:\n" + ex.getMessage(),
                    "Erro na consulta",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void carregarTreinoSelecionado() {
        int linha = jTable2.getSelectedRow();

        if (linha == -1) {
            return;
        }

        try {
            linha = jTable2.convertRowIndexToModel(linha);

            int idTreino = Integer.parseInt(
                    jTable2.getModel().getValueAt(linha, 0).toString());

            jTidAluno.setText(
                    jTable2.getModel().getValueAt(linha, 1).toString());

            Object idProfissional
                    = jTable2.getModel().getValueAt(linha, 2);

            jTidProfissional.setText(
                    idProfissional == null ? "" : idProfissional.toString());

            jTdata.setText(
                    jTable2.getModel().getValueAt(linha, 3).toString());

            jTnomeTreino.setText(
                    jTable2.getModel().getValueAt(linha, 4).toString());

            jTstatus.setText(
                    jTable2.getModel().getValueAt(linha, 5).toString());

            TreinoDAO dao = new TreinoDAO();

            exercicios = dao.consultarExercicios(idTreino);

            DefaultTableModel modelo
                    = (DefaultTableModel) jTable1.getModel();

            modelo.setRowCount(0);

            for (TreinoExercicio e : exercicios) {
                modelo.addRow(new Object[]{
                    e.getIdExercicio(),
                    e.getQuantidadeSeries(),
                    e.getRepeticoes(),
                    e.getCarga(),
                    e.getTempoDescanso(),
                    e.getOrdemExecucao()
                });
            }

        } catch (Exception ex) {
            mostrarErroBanco(ex);
        }
    }

    private void limparCampos() {
        jTidAluno.setText("");
        jTidProfissional.setText("");
        jTdata.setText("");
        jTnomeTreino.setText("");
        jTstatus.setText("");

        jTidExercicio.setText("");
        jTseries.setText("");
        jTrepeticoes.setText("");
        jTcarga.setText("");
        jTdescanso.setText("");
        jTordem.setText("");

        exercicios.clear();

        DefaultTableModel modelo
                = (DefaultTableModel) jTable1.getModel();
        modelo.setRowCount(0);

        jTidAluno.requestFocus();
    }

    private ArrayList<TreinoExercicio> exercicios = new ArrayList<>();
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(CadastrarTreino.class.getName());

    /**
     * Creates new form CadastrarTreino
     */
    public CadastrarTreino() {
        initComponents();
        jTable1.setModel(new DefaultTableModel(
                new Object[][]{},
                new String[]{"ID Exercício", "Séries", "Repetições",
                    "Carga", "Descanso", "Ordem"}
        ));

        jTable2.setModel(new DefaultTableModel(
                new Object[][]{},
                new String[]{"ID Treino", "ID Aluno", "ID Profissional",
                    "Data", "Nome", "Status", "Matrícula Aluno"}
        ));

        jTable2.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()
                    && jTable2.getSelectedRow() != -1) {
                carregarTreinoSelecionado();
            }
        });
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jTidAluno = new javax.swing.JTextField();
        jTidProfissional = new javax.swing.JTextField();
        jTdata = new javax.swing.JTextField();
        jTnomeTreino = new javax.swing.JTextField();
        jTstatus = new javax.swing.JTextField();
        jTidExercicio = new javax.swing.JTextField();
        jTseries = new javax.swing.JTextField();
        jTrepeticoes = new javax.swing.JTextField();
        jTcarga = new javax.swing.JTextField();
        jTdescanso = new javax.swing.JTextField();
        jTordem = new javax.swing.JTextField();
        jBcadastrar = new javax.swing.JButton();
        jBconsultar = new javax.swing.JButton();
        jBalterar = new javax.swing.JButton();
        jBexcluir = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jBadicionar = new javax.swing.JButton();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jButton1.setText("jButton1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Id aluno:");

        jLabel2.setText("Id profissional:");

        jLabel3.setText("Data: AAAA-MM-DD");

        jLabel4.setText("Nome do treino:");

        jLabel5.setText("Status:");

        jLabel6.setText("Id exercício:");

        jLabel7.setText("Séries:");

        jLabel8.setText("Repetições:");

        jLabel9.setText("Carga:");

        jLabel10.setText("Descanço:");

        jLabel11.setText("Orderm:");

        jBcadastrar.setText("Cadastrar");
        jBcadastrar.addActionListener(this::jBcadastrarActionPerformed);

        jBconsultar.setText("Consultar");
        jBconsultar.addActionListener(this::jBconsultarActionPerformed);

        jBalterar.setText("Alterar");
        jBalterar.addActionListener(this::jBalterarActionPerformed);

        jBexcluir.setText("Excluir");
        jBexcluir.addActionListener(this::jBexcluirActionPerformed);

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "ID Treino", "ID Aluno", "ID Profissional", "Data", "Nome", "Status", "Matrícula Aluno"
            }
        ));
        jScrollPane2.setViewportView(jTable2);

        jBadicionar.setText("Adicionar");
        jBadicionar.addActionListener(this::jBadicionarActionPerformed);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jTidAluno, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(jTidProfissional, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jTdata, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jTnomeTreino, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jTidExercicio, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jTseries, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jTcarga, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                            .addComponent(jTstatus, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(18, 18, 18)
                                            .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(jTordem, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                            .addComponent(jTrepeticoes, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(18, 18, 18)
                                            .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(jTdescanso, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jBcadastrar)
                                .addGap(18, 18, 18)
                                .addComponent(jBconsultar)
                                .addGap(18, 18, 18)
                                .addComponent(jBalterar)
                                .addGap(18, 18, 18)
                                .addComponent(jBexcluir)
                                .addGap(18, 18, 18)
                                .addComponent(jBadicionar)))
                        .addGap(0, 42, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jTidAluno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(jTidProfissional, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jTdata, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4)
                    .addComponent(jTnomeTreino, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(jTidExercicio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7)
                    .addComponent(jTseries, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(jTrepeticoes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10)
                    .addComponent(jTdescanso, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jTstatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTordem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel9)
                    .addComponent(jTcarga, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jBcadastrar)
                    .addComponent(jBconsultar)
                    .addComponent(jBalterar)
                    .addComponent(jBexcluir)
                    .addComponent(jBadicionar))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jBcadastrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBcadastrarActionPerformed
        // TODO add your handling code here:
        try {
            Treino treino = new Treino();

            treino.setIdPessoaAluno(
                    Integer.parseInt(jTidAluno.getText()));
            treino.setIdPessoaProfissional(
                    Integer.parseInt(jTidProfissional.getText()));
            treino.setDataPrescricao(jTdata.getText());
            treino.setNomeTreino(jTnomeTreino.getText());
            treino.setStatusTreino(jTstatus.getText().toLowerCase());

            if (exercicios.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "Adicione pelo menos um exercício.");
                return;
            }

            TreinoDAO dao = new TreinoDAO();
            dao.criarTreinoComExercicios(treino, exercicios);

            JOptionPane.showMessageDialog(this,
                    "Treino cadastrado com sucesso!");

            limparCampos();
            consultarTreinos();

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this,
                    "Informe IDs válidos para aluno e profissional.");
        } catch (Exception ex) {
            mostrarErroBanco(ex);
        }
    }//GEN-LAST:event_jBcadastrarActionPerformed

    private void jBadicionarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBadicionarActionPerformed
        // TODO add your handling code here:
        try {
            TreinoExercicio e = new TreinoExercicio();

            e.setIdExercicio(Integer.parseInt(jTidExercicio.getText()));
            e.setQuantidadeSeries(Integer.parseInt(jTseries.getText()));
            e.setRepeticoes(Integer.parseInt(jTrepeticoes.getText()));

            if (jTcarga.getText().trim().isEmpty()) {
                e.setCarga(0);
            } else {
                e.setCarga(Double.parseDouble(
                        jTcarga.getText().replace(",", ".")));
            }

            e.setTempoDescanso(Integer.parseInt(jTdescanso.getText()));
            e.setOrdemExecucao(Integer.parseInt(jTordem.getText()));

            exercicios.add(e);

            DefaultTableModel modelo
                    = (DefaultTableModel) jTable1.getModel();

            modelo.addRow(new Object[]{
                e.getIdExercicio(),
                e.getQuantidadeSeries(),
                e.getRepeticoes(),
                e.getCarga(),
                e.getTempoDescanso(),
                e.getOrdemExecucao()
            });

            jTidExercicio.setText("");
            jTseries.setText("");
            jTrepeticoes.setText("");
            jTcarga.setText("");
            jTdescanso.setText("");
            jTordem.setText("");
            jTidExercicio.requestFocus();

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this,
                    "Preencha os campos do exercício com valores válidos.");
        }
    }//GEN-LAST:event_jBadicionarActionPerformed

    private void jBconsultarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBconsultarActionPerformed
        // TODO add your handling code here:
        consultarTreinos();
    }//GEN-LAST:event_jBconsultarActionPerformed

    private void jBalterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBalterarActionPerformed
        // TODO add your handling code here:
        int linha = jTable2.getSelectedRow();

        if (linha == -1) {
            JOptionPane.showMessageDialog(this,
                    "Selecione um treino na tabela para alterar.");
            return;
        }

        try {
            Treino treino = new Treino();

            treino.setIdTreino(
                    Integer.parseInt(jTable2.getValueAt(linha, 0).toString()));
            treino.setIdPessoaAluno(
                    Integer.parseInt(jTidAluno.getText()));
            treino.setIdPessoaProfissional(
                    Integer.parseInt(jTidProfissional.getText()));
            treino.setDataPrescricao(jTdata.getText());
            treino.setNomeTreino(jTnomeTreino.getText());
            treino.setStatusTreino(jTstatus.getText().toLowerCase());

            TreinoDAO dao = new TreinoDAO();
            dao.alterarTreinoComExercicios(treino, exercicios);

            JOptionPane.showMessageDialog(this,
                    "Treino alterado com sucesso!");

            limparCampos();
            consultarTreinos();

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this,
                    "Confira os IDs informados.");
        } catch (Exception ex) {
            mostrarErroBanco(ex);
        }
    }//GEN-LAST:event_jBalterarActionPerformed

    private void jBexcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBexcluirActionPerformed
        // TODO add your handling code here:
        int linha = jTable2.getSelectedRow();

        if (linha == -1) {
            JOptionPane.showMessageDialog(this,
                    "Selecione um treino na tabela para excluir.");
            return;
        }

        int resposta = JOptionPane.showConfirmDialog(this,
                "Deseja realmente excluir este treino?",
                "Confirmar exclusão",
                JOptionPane.YES_NO_OPTION);

        if (resposta == JOptionPane.YES_OPTION) {
            try {
                int idTreino = Integer.parseInt(
                        jTable2.getValueAt(linha, 0).toString());

                TreinoDAO dao = new TreinoDAO();
                dao.excluirTreino(idTreino);

                JOptionPane.showMessageDialog(this,
                        "Treino excluído com sucesso!");

                consultarTreinos();

            } catch (Exception ex) {
                mostrarErroBanco(ex);
            }
        }
    }//GEN-LAST:event_jBexcluirActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new CadastrarTreino().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jBadicionar;
    private javax.swing.JButton jBalterar;
    private javax.swing.JButton jBcadastrar;
    private javax.swing.JButton jBconsultar;
    private javax.swing.JButton jBexcluir;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTextField jTcarga;
    private javax.swing.JTextField jTdata;
    private javax.swing.JTextField jTdescanso;
    private javax.swing.JTextField jTidAluno;
    private javax.swing.JTextField jTidExercicio;
    private javax.swing.JTextField jTidProfissional;
    private javax.swing.JTextField jTnomeTreino;
    private javax.swing.JTextField jTordem;
    private javax.swing.JTextField jTrepeticoes;
    private javax.swing.JTextField jTseries;
    private javax.swing.JTextField jTstatus;
    // End of variables declaration//GEN-END:variables
}
