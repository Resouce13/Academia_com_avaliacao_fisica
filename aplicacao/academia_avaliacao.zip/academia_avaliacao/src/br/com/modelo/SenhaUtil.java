package br.com.modelo;

import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.SecureRandom;
import java.util.Base64;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public class SenhaUtil {

    private static final int ITERACOES = 600000;
    private static final int TAMANHO_HASH = 256;
    private static final int TAMANHO_SALT = 16;

    private static final SecureRandom RANDOM = new SecureRandom();

    public static String gerarSalt() {
        byte[] salt = new byte[TAMANHO_SALT];
        RANDOM.nextBytes(salt);

        return Base64.getEncoder().encodeToString(salt);
    }

    public static String gerarHash(String senha, String saltBase64)
            throws GeneralSecurityException {

        byte[] salt = Base64.getDecoder().decode(saltBase64);

        PBEKeySpec especificacao = new PBEKeySpec(
                senha.toCharArray(),
                salt,
                ITERACOES,
                TAMANHO_HASH
        );

        try {
            SecretKeyFactory fabrica
                    = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");

            byte[] hash = fabrica.generateSecret(especificacao).getEncoded();

            return Base64.getEncoder().encodeToString(hash);
        } finally {
            especificacao.clearPassword();
        }
    }

    public static boolean verificarSenha(
            String senhaDigitada,
            String saltBase64,
            String hashArmazenado)
            throws GeneralSecurityException {

        String hashCalculado = gerarHash(senhaDigitada, saltBase64);

        byte[] hash1 = Base64.getDecoder().decode(hashCalculado);
        byte[] hash2 = Base64.getDecoder().decode(hashArmazenado);

        return java.security.MessageDigest.isEqual(hash1, hash2);
    }

    public static int getIteracoes() {
        return ITERACOES;
    }
}
