/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.controle;

/**
 *
 * @author Gabriel_DEV
 */
public class Plano {

    private int id_plano;
    private String nome_plano;
    private float valor_mensal;
    private int duracao_meses;

    public int getId_plano() {
        return id_plano;
    }

    public void setId_plano(int id_plano) {
        this.id_plano = id_plano;
    }

    public String getNome_plano() {
        return nome_plano;
    }

    public void setNome_plano(String nome_plano) {
        this.nome_plano = nome_plano;
    }

    public float getValor_mensal() {
        return valor_mensal;
    }

    public void setValor_mensal(float valor_mensal) {
        this.valor_mensal = valor_mensal;
    }

    public int getDuracao_meses() {
        return duracao_meses;
    }

    public void setDuracao_meses(int duracao_meses) {
        this.duracao_meses = duracao_meses;
    }

    // Métodos sem "_"

    public int getIdPlano() {
        return id_plano;
    }

    public void setIdPlano(int idPlano) {
        this.id_plano = idPlano;
    }

    public String getNomePlano() {
        return nome_plano;
    }

    public void setNomePlano(String nomePlano) {
        this.nome_plano = nomePlano;
    }

    public float getValorMensal() {
        return valor_mensal;
    }

    public void setValorMensal(float valorMensal) {
        this.valor_mensal = valorMensal;
    }

    public int getDuracaoMeses() {
        return duracao_meses;
    }

    public void setDuracaoMeses(int duracaoMeses) {
        this.duracao_meses = duracaoMeses;
    }
}