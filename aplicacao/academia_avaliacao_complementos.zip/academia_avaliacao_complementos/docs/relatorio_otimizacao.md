# Relatório de otimização — B4

Este documento deve ser preenchido com os resultados reais dos três experimentos. Não invente tempos nem copie estimativas como se fossem tempo medido.

## Estudo 1 — filtro por grupo muscular

- Tabela de teste usada: `exercicio_teste` (confirmar no script B4 atual).
- Volume conhecido em um teste anterior: aproximadamente 500 linhas.
- Índice testado: `idx_exercicio_grupo` sobre a coluna `grupo_muscular`.
- Plano antes: foi observado acesso `ALL`, com estimativa de 500 linhas.
- Plano depois: foi observado acesso `ref`, usando `idx_exercicio_grupo`, com estimativa de 62 linhas.
- Tempo antes: preencher com a medição real.
- Tempo depois: preencher com a medição real.
- Interpretação: o plano passou de varredura completa para busca pelo índice. A estimativa de linhas não é o tempo de execução e não garante, por si só, uma melhora mensurável em toda carga.

## Estudo 2 — avaliação física por aluno e intervalo de datas

Consulta-base sugerida (ajuste ao script de teste e registre o volume de dados):

```sql
EXPLAIN ANALYZE
SELECT id_avaliacao, id_pessoa_aluno, data_avaliacao
FROM avaliacao_fisica
WHERE id_pessoa_aluno = 3
  AND data_avaliacao BETWEEN '2026-01-01' AND '2026-12-31';
```

O DDL da Etapa 1 já contém `idx_avaliacao_aluno_data (id_pessoa_aluno, data_avaliacao)`. Para comparar antes/depois de forma justa, use uma cópia descartável da tabela ou uma tabela de teste equivalente sem esse índice; não remova o índice do banco principal só para a demonstração. Registre plano, tempo e quantidade de linhas.

- Plano antes:
- Índice avaliado:
- Plano depois:
- Tempo antes/depois:
- Volume de dados:
- Conclusão baseada no que foi observado:

## Estudo 3 — contratos por aluno e período

Consulta-base sugerida:

```sql
EXPLAIN ANALYZE
SELECT id_contrato, id_pessoa_aluno, data_inicio, data_termino, situacao
FROM contrato
WHERE id_pessoa_aluno = 3
  AND data_inicio <= '2026-12-31'
  AND data_termino >= '2026-01-01';
```

O DDL da Etapa 1 já contém `idx_contrato_aluno_datas (id_pessoa_aluno, data_inicio, data_termino)`. Faça a comparação em cópia descartável ou tabela de teste para preservar o banco principal. A ordem das colunas do índice deve ser justificada pela forma como a consulta filtra; não presuma que todas as colunas do índice serão usadas igualmente pelo otimizador.

- Plano antes:
- Índice avaliado:
- Plano depois:
- Tempo antes/depois:
- Volume de dados:
- Conclusão baseada no que foi observado:

## Como coletar as evidências
1. Registre a versão do MySQL e o volume de dados.
2. Execute a consulta de teste antes da intervenção e salve o plano.
3. Crie o índice na tabela de teste e execute novamente.
4. Salve o plano depois e o tempo reportado por `EXPLAIN ANALYZE`.
5. Compare o tipo de acesso, índice escolhido, linhas estimadas/observadas e tempo.
6. Se o índice não ajudar, registre isso e explique. Um resultado negativo bem analisado é aceitável.

**Não apresente os estudos 2 e 3 como concluídos até executar as medições reais.**
