
package br.com.modelo;

public class TesteSenha {

    public static void main(String[] args) throws Exception {

        // Senha fictícia usada apenas para o teste
        String senha = "Teste@123";

        String salt = SenhaUtil.gerarSalt();
        String hash = SenhaUtil.gerarHash(senha, salt);

        boolean senhaCorreta =
            SenhaUtil.verificarSenha(senha, salt, hash);

        boolean senhaIncorreta =
            SenhaUtil.verificarSenha("SenhaErrada", salt, hash);

        System.out.println("Salt gerado: " + salt);
        System.out.println("Hash gerado: " + hash);
        System.out.println("Senha correta validada: " + senhaCorreta);
        System.out.println("Senha incorreta validada: " + senhaIncorreta);
    }
}