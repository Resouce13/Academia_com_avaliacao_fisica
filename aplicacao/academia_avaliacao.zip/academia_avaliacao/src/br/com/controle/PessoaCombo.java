package br.com.controle;

public class PessoaCombo {

    private int idPessoa;
    private String nome;

    public PessoaCombo(int idPessoa, String nome) {
        this.idPessoa = idPessoa;
        this.nome = nome;
    }

    public int getIdPessoa() {
        return idPessoa;
    }

    public void setIdPessoa(int idPessoa) {
        this.idPessoa = idPessoa;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    @Override
    public String toString() {
        return idPessoa + " - " + nome;
    }
}
