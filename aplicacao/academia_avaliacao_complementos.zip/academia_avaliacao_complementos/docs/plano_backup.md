# Plano de backup e restauração

## Estratégia proposta
- Antes de cada alteração estrutural: backup lógico completo.
- Durante o desenvolvimento: backup ao fim de cada sessão importante.
- Antes da entrega: backup final e cópia fora do repositório.
- Retenção sugerida: 7 cópias diárias e 4 semanais.
- Teste de restauração em banco separado antes de confiar no backup.

## Backup lógico
No terminal, com o cliente MySQL instalado:

```bash
mysqldump -u SEU_USUARIO -p --single-transaction --routines --triggers academia_avaliacao > academia_avaliacao_backup.sql
```

A senha será solicitada interativamente. Não coloque senha no comando nem versione o dump se contiver dados pessoais.

## Restauração de teste
Crie um banco separado:
```sql
CREATE DATABASE academia_avaliacao_teste_restore;
```
Revise o dump para confirmar que não contém comandos que sobrescrevam o banco original. Então restaure no banco de teste:
```bash
mysql -u SEU_USUARIO -p academia_avaliacao_teste_restore < academia_avaliacao_backup.sql
```

## Verificação
1. Conferir tabelas, views, índices e gatilhos.
2. Comparar contagens de registros importantes.
3. Executar consultas de verificação.
4. Conferir separadamente scripts de roles e permissões: o dump de dados não deve ser tratado como garantia de recriação dos usuários/roles do servidor.
5. Registrar data, responsável, resultado e erros.

Este é um plano proposto. Só marque como realizado depois de executar o backup e a restauração de teste.
