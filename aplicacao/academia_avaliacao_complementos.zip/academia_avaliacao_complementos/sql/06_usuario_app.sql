-- Estrutura para autenticação da aplicação; precisa ser integrada ao Java.
USE academia_avaliacao;
CREATE TABLE IF NOT EXISTS usuario_app (
    id_usuario INT UNSIGNED NOT NULL AUTO_INCREMENT,
    nome_usuario VARCHAR(80) NOT NULL,
    hash_senha VARCHAR(255) NOT NULL,
    sal_senha VARCHAR(255) NOT NULL,
    perfil ENUM('ADMIN', 'FUNCIONARIO', 'CONSULTA') NOT NULL,
    ativo BOOLEAN NOT NULL DEFAULT TRUE,
    criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT pk_usuario_app PRIMARY KEY (id_usuario),
    CONSTRAINT uq_usuario_app_nome UNIQUE (nome_usuario)
) ENGINE = InnoDB;
-- Nunca armazene a senha em texto puro. Gere hash e sal na aplicação usando
-- PBKDF2-HMAC-SHA256 e salve os valores codificados em Base64.
-- Não insira senhas reais neste script ou no GitHub.
