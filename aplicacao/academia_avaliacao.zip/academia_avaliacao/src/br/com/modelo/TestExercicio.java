/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.modelo;
import br.com.controle.Exercicio;

/**
 *
 * @author Gabriel_DEV
 */
public class TestExercicio {

    public static void main(String[] args) throws Exception {

        Exercicio e = new Exercicio();

        e.setNomeExercicio("Supino Inclinado");
        e.setGrupoMuscular("Peito");

        ExercicioDAO dao = new ExercicioDAO();

        dao.inserir(e);

        System.out.println("Teste concluído!");
    }
}