package br.com.controle;

public class ConsultaAluno {

    private int idPessoa;
    private String nomeAluno;
    private String matricula;
    private int quantidadeTreinos;

    public int getIdPessoa() {
        return idPessoa;
    }

    public void setIdPessoa(int idPessoa) {
        this.idPessoa = idPessoa;
    }

    public String getNomeAluno() {
        return nomeAluno;
    }

    public void setNomeAluno(String nomeAluno) {
        this.nomeAluno = nomeAluno;
    }

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public int getQuantidadeTreinos() {
        return quantidadeTreinos;
    }

    public void setQuantidadeTreinos(int quantidadeTreinos) {
        this.quantidadeTreinos = quantidadeTreinos;
    }
}