/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.modelo;

/**
 *
 * @author Gabriel_DEV
 */
import br.com.controle.ConsultaAluno;
import br.com.controle.ConsultaExercicio;
import br.com.controle.RelatorioAluno;
import java.util.ArrayList;

public class ConsultaDAO extends DAO {

    public ArrayList<ConsultaAluno> alunosPorMatricula(String matricula) throws Exception {

        ArrayList<ConsultaAluno> lista = new ArrayList<>();

        try {

            abrirBanco();

            String query
                    = "SELECT "
                    + "p.id_pessoa, "
                    + "p.nome AS aluno, "
                    + "a.matricula, "
                    + "COUNT(t.id_treino) AS quantidade_treinos "
                    + "FROM aluno a "
                    + "JOIN pessoa p "
                    + "ON p.id_pessoa = a.id_pessoa "
                    + "LEFT JOIN treino t "
                    + "ON t.id_pessoa_aluno = a.id_pessoa "
                    + "WHERE a.matricula = ? "
                    + "GROUP BY "
                    + "p.id_pessoa, p.nome, a.matricula "
                    + "ORDER BY p.nome";

            pst = con.prepareStatement(query);

            pst.setString(1, matricula);

            rs = pst.executeQuery();

            while (rs.next()) {

                ConsultaAluno consulta = new ConsultaAluno();

                consulta.setIdPessoa(
                        rs.getInt("id_pessoa")
                );

                consulta.setNomeAluno(
                        rs.getString("aluno")
                );

                consulta.setMatricula(
                        rs.getString("matricula")
                );

                consulta.setQuantidadeTreinos(
                        rs.getInt("quantidade_treinos")
                );

                lista.add(consulta);
            }

        } finally {

            fecharBanco();
        }

        return lista;
    }

    public ArrayList<ConsultaExercicio> exerciciosPorGrupoMuscular(String grupoMuscular) throws Exception {

        ArrayList<ConsultaExercicio> lista = new ArrayList<>();

        try {
            abrirBanco();

            String query
                    = "SELECT "
                    + "e.nome_exercicio, "
                    + "e.grupo_muscular, "
                    + "COUNT(te.id_treino) AS quantidade_treinos "
                    + "FROM exercicio e "
                    + "JOIN treino_exercicio te "
                    + "ON te.id_exercicio = e.id_exercicio "
                    + "WHERE e.grupo_muscular = ? "
                    + "GROUP BY "
                    + "e.id_exercicio, "
                    + "e.nome_exercicio, "
                    + "e.grupo_muscular "
                    + "ORDER BY e.nome_exercicio";

            pst = con.prepareStatement(query);

            pst.setString(1, grupoMuscular);

            rs = pst.executeQuery();

            while (rs.next()) {

                ConsultaExercicio consulta = new ConsultaExercicio();

                consulta.setNomeExercicio(
                        rs.getString("nome_exercicio")
                );

                consulta.setGrupoMuscular(
                        rs.getString("grupo_muscular")
                );

                consulta.setQuantidadeTreinos(
                        rs.getInt("quantidade_treinos")
                );

                lista.add(consulta);
            }

        } finally {
            fecharBanco();
        }

        return lista;
    }

    public ArrayList<RelatorioAluno> listarRelatorioAlunos() throws Exception {
        ArrayList<RelatorioAluno> lista = new ArrayList<>();

        try {
            abrirBanco();

            String query
                    = "SELECT "
                    + "id_pessoa, "
                    + "aluno, "
                    + "matricula, "
                    + "status_matricula, "
                    + "qtd_treinos, "
                    + "qtd_avaliacoes "
                    + "FROM vw_relatorio_alunos "
                    + "ORDER BY aluno";

            pst = con.prepareStatement(query);
            rs = pst.executeQuery();

            while (rs.next()) {
                RelatorioAluno relatorio = new RelatorioAluno();

                relatorio.setIdPessoa(rs.getInt("id_pessoa"));
                relatorio.setNome(rs.getString("aluno"));
                relatorio.setMatricula(rs.getString("matricula"));
                relatorio.setStatusMatricula(rs.getString("status_matricula"));

                relatorio.setQuantidadeTreinos(
                        rs.getInt("qtd_treinos")
                );

                relatorio.setQuantidadeAvaliacoes(
                        rs.getInt("qtd_avaliacoes")
                );

                lista.add(relatorio);
            }

        } finally {
            fecharBanco();
        }

        return lista;
    }
}
