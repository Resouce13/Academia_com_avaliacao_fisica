/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.controle;

/**
 *
 * @author Gabriel_DEV
 */
public class Treino {

    private int idTreino;
    private int idPessoaAluno;
    private int idPessoaProfissional;
    private String dataPrescricao;
    private String nomeTreino;
    private String statusTreino;

    public int getIdTreino() {
        return idTreino;
    }

    public void setIdTreino(int idTreino) {
        this.idTreino = idTreino;
    }

    public int getIdPessoaAluno() {
        return idPessoaAluno;
    }

    public void setIdPessoaAluno(int idPessoaAluno) {
        this.idPessoaAluno = idPessoaAluno;
    }

    public int getIdPessoaProfissional() {
        return idPessoaProfissional;
    }

    public void setIdPessoaProfissional(int idPessoaProfissional) {
        this.idPessoaProfissional = idPessoaProfissional;
    }

    public String getDataPrescricao() {
        return dataPrescricao;
    }

    public void setDataPrescricao(String dataPrescricao) {
        this.dataPrescricao = dataPrescricao;
    }

    public String getNomeTreino() {
        return nomeTreino;
    }

    public void setNomeTreino(String nomeTreino) {
        this.nomeTreino = nomeTreino;
    }

    public String getStatusTreino() {
        return statusTreino;
    }

    public void setStatusTreino(String statusTreino) {
        this.statusTreino = statusTreino;
    }
}