package br.com.modelo;

import br.com.controle.ConsultaAluno;
import java.util.ArrayList;

/**
 * Demonstração B2: tentativas de injeção de SQL contra a consulta
 * parametrizada ConsultaDAO.alunosPorMatricula(String).
 * Execute (Run File) e copie a saída para o relatório.
 */
public class TesteInjecao {

    public static void main(String[] args) throws Exception {
        ConsultaDAO dao = new ConsultaDAO();

        String[] entradas = {
            "2025ALU0001", // entrada legítima (controle)
            "' OR '1'='1", // tautologia clássica
            "x' OR 1=1 -- ", // tautologia + comentário
            "'; DROP TABLE aluno; -- ", // consulta empilhada
            "' UNION SELECT id_pessoa, cpf, email, 0 FROM pessoa -- " // extração via UNION
        };

        for (String entrada : entradas) {
            ArrayList<ConsultaAluno> r = dao.alunosPorMatricula(entrada);
            System.out.println("Entrada : [" + entrada + "]");
            System.out.println("Linhas  : " + r.size());
            System.out.println("---");
        }

        int total = new AlunoDAO().listar().size();
        System.out.println("Tabela aluno íntegra. Alunos cadastrados: " + total);
    }
}