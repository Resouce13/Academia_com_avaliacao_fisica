/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.modelo;

/**
 *
 * @author Gabriel_DEV
 */
import br.com.controle.Plano;

public class TestPlano {

    public static void main(String[] args) throws Exception {

        Plano p = new Plano();

        p.setNomePlano("Plano Premium");
        p.setValorMensal(149.90f);
        p.setDuracaoMeses(12);

        PlanoDAO dao = new PlanoDAO();

        dao.inserir(p);

        System.out.println("Teste concluído!");
    }
}