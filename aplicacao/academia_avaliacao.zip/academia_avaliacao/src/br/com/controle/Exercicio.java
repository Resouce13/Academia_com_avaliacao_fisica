/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.controle;

/**
 *
 * @author Gabriel_DEV
 */
public class Exercicio {

    private int id_exercicio;
    private String nome_exercicio;
    private String grupo_muscular;

    public int getId_exercicio() {
        return id_exercicio;
    }

    public void setId_exercicio(int id_exercicio) {
        this.id_exercicio = id_exercicio;
    }

    public String getNome_exercicio() {
        return nome_exercicio;
    }

    public void setNome_exercicio(String nome_exercicio) {
        this.nome_exercicio = nome_exercicio;
    }

    public String getGrupo_muscular() {
        return grupo_muscular;
    }

    public void setGrupo_muscular(String grupo_muscular) {
        this.grupo_muscular = grupo_muscular;
    }

    // Métodos usados pelo TestExercicio

    public int getIdExercicio() {
        return id_exercicio;
    }

    public void setIdExercicio(int idExercicio) {
        this.id_exercicio = idExercicio;
    }

    public String getNomeExercicio() {
        return nome_exercicio;
    }

    public void setNomeExercicio(String nomeExercicio) {
        this.nome_exercicio = nomeExercicio;
    }

    public String getGrupoMuscular() {
        return grupo_muscular;
    }

    public void setGrupoMuscular(String grupoMuscular) {
        this.grupo_muscular = grupoMuscular;
    }
}