# Experimento de concorrência — duas sessões MySQL

## Preparação
Abra duas conexões independentes no Workbench (Sessão A e Sessão B) apontando para uma cópia de teste. Nas duas, execute:

```sql
USE academia_avaliacao;
SELECT @@transaction_isolation;
```

Registre o valor efetivamente retornado.

## Sessão A — primeiro
```sql
START TRANSACTION;
SELECT id_treino, nome_treino FROM treino WHERE id_treino = 1 FOR UPDATE;
```
Deixe a transação aberta.

## Sessão B — enquanto A está aberta
```sql
START TRANSACTION;
SELECT id_treino, nome_treino FROM treino WHERE id_treino = 1 FOR UPDATE;
```
Observe e registre se B aguarda o bloqueio.

## Volte à Sessão A
```sql
COMMIT;
```
Depois que B prosseguir, finalize B:
```sql
COMMIT;
```

O teste não altera dados; ele demonstra o bloqueio de leitura para atualização. No InnoDB, uma segunda transação que solicita bloqueio incompatível para a mesma linha pode aguardar a liberação pela primeira transação.

## Evidências
Registre a versão do MySQL, isolamento observado, tempo/comportamento real, capturas das duas sessões e o que ocorreu após o `COMMIT`. Não afirme que houve espera ou deadlock sem observar. Esse teste demonstra o mecanismo de bloqueio, mas não prova sozinho que todos os fluxos da aplicação estejam livres de deadlocks.
