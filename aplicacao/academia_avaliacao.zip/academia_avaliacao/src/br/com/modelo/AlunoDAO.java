package br.com.modelo;

import br.com.controle.Aluno;
import br.com.controle.Pessoa;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class AlunoDAO extends DAO {

    // CADASTRAR PESSOA + ALUNO
    public void inserir(Aluno aluno) throws Exception {

        Pessoa pessoa = aluno.getPessoa();

        if (pessoa == null) {
            throw new IllegalArgumentException(
                    "Os dados da pessoa não foram informados."
            );
        }

        try {
            abrirBanco();
            con.setAutoCommit(false);

            // 1. Cadastra a pessoa
            String sqlPessoa
                    = "INSERT INTO pessoa "
                    + "(nome, cpf, data_nascimento, telefone, email, "
                    + "rua, numero, bairro, cidade, uf, cep) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            try (PreparedStatement stmt = con.prepareStatement(
                    sqlPessoa, PreparedStatement.RETURN_GENERATED_KEYS)) {

                stmt.setString(1, pessoa.getNome());
                stmt.setString(2, pessoa.getCpf());
                stmt.setString(3, pessoa.getDataNascimento());
                stmt.setString(4, pessoa.getTelefone());
                stmt.setString(5, pessoa.getEmail());
                stmt.setString(6, pessoa.getRua());
                stmt.setString(7, pessoa.getNumero());
                stmt.setString(8, pessoa.getBairro());
                stmt.setString(9, pessoa.getCidade());
                stmt.setString(10, pessoa.getUf());
                stmt.setString(11, pessoa.getCep());

                stmt.executeUpdate();

                try (ResultSet chaves = stmt.getGeneratedKeys()) {
                    if (!chaves.next()) {
                        throw new Exception(
                                "Não foi possível obter o ID da pessoa."
                        );
                    }

                    int idPessoa = chaves.getInt(1);
                    pessoa.setIdPessoa(idPessoa);
                    aluno.setIdPessoa(idPessoa);
                }
            }

            // 2. Cadastra o aluno com o ID da pessoa
            String sqlAluno
                    = "INSERT INTO aluno "
                    + "(id_pessoa, matricula, status_matricula) "
                    + "VALUES (?, ?, ?)";

            try (PreparedStatement stmt = con.prepareStatement(sqlAluno)) {
                stmt.setInt(1, aluno.getIdPessoa());
                stmt.setString(2, aluno.getMatricula());
                stmt.setString(3, aluno.getStatusMatricula());
                stmt.executeUpdate();
            }

            // 3. Confirma as duas operações
            con.commit();

        } catch (Exception e) {

            if (con != null) {
                try {
                    con.rollback();
                } catch (Exception erroRollback) {
                    e.addSuppressed(erroRollback);
                }
            }

            throw e;

        } finally {

            if (con != null) {
                try {
                    con.setAutoCommit(true);
                } finally {
                    fecharBanco();
                }
            }
        }
    }

    // CONSULTAR ALUNO
    public Aluno consultar(int idPessoa) throws Exception {

        Aluno aluno = null;

        try {
            abrirBanco();

            String query
                    = "SELECT id_pessoa, matricula, status_matricula "
                    + "FROM aluno WHERE id_pessoa = ?";

            pst = con.prepareStatement(query);
            pst.setInt(1, idPessoa);
            rs = pst.executeQuery();

            if (rs.next()) {
                aluno = new Aluno();
                aluno.setIdPessoa(rs.getInt("id_pessoa"));
                aluno.setMatricula(rs.getString("matricula"));
                aluno.setStatusMatricula(
                        rs.getString("status_matricula")
                );
            }

        } finally {
            fecharBanco();
        }

        return aluno;
    }

    // LISTAR ALUNOS
    public ArrayList<Aluno> listar() throws Exception {

        ArrayList<Aluno> lista = new ArrayList<>();

        try {
            abrirBanco();

            String query
                    = "SELECT id_pessoa, matricula, status_matricula "
                    + "FROM aluno ORDER BY matricula";

            pst = con.prepareStatement(query);
            rs = pst.executeQuery();

            while (rs.next()) {
                Aluno aluno = new Aluno();
                aluno.setIdPessoa(rs.getInt("id_pessoa"));
                aluno.setMatricula(rs.getString("matricula"));
                aluno.setStatusMatricula(
                        rs.getString("status_matricula")
                );
                lista.add(aluno);
            }

        } finally {
            fecharBanco();
        }

        return lista;
    }

    // ALTERAR ALUNO
    public void alterar(Aluno aluno) throws Exception {

        try {
            abrirBanco();

            String query
                    = "UPDATE aluno SET matricula = ?, "
                    + "status_matricula = ? WHERE id_pessoa = ?";

            pst = con.prepareStatement(query);
            pst.setString(1, aluno.getMatricula());
            pst.setString(2, aluno.getStatusMatricula());
            pst.setInt(3, aluno.getIdPessoa());

            pst.executeUpdate();

        } finally {
            fecharBanco();
        }
    }

    // EXCLUIR ALUNO E PESSOA
    public void excluir(int idPessoa) throws Exception {

        try {
            abrirBanco();
            con.setAutoCommit(false);

            String sqlAluno
                    = "DELETE FROM aluno WHERE id_pessoa = ?";

            pst = con.prepareStatement(sqlAluno);
            pst.setInt(1, idPessoa);
            pst.executeUpdate();
            pst.close();
            pst = null;

            String sqlPessoa
                    = "DELETE FROM pessoa WHERE id_pessoa = ?";

            pst = con.prepareStatement(sqlPessoa);
            pst.setInt(1, idPessoa);
            pst.executeUpdate();

            con.commit();

        } catch (Exception e) {

            if (con != null) {
                try {
                    con.rollback();
                } catch (Exception erroRollback) {
                    e.addSuppressed(erroRollback);
                }
            }

            throw e;

        } finally {

            if (con != null) {
                try {
                    con.setAutoCommit(true);
                } finally {
                    fecharBanco();
                }
            }
        }
    }
    // CONSULTAR ALUNOS POR MATRÍCULA E STATUS

    public ArrayList<Aluno> consultarPorFiltro(
            String matricula, String status) throws Exception {

        ArrayList<Aluno> lista = new ArrayList<>();

        try {
            abrirBanco();

            String query
                    = "SELECT id_pessoa, matricula, status_matricula "
                    + "FROM aluno "
                    + "WHERE matricula LIKE ? "
                    + "AND status_matricula LIKE ? "
                    + "ORDER BY matricula";

            pst = con.prepareStatement(query);
            pst.setString(1, "%" + matricula + "%");
            pst.setString(2, "%" + status + "%");

            rs = pst.executeQuery();

            while (rs.next()) {
                Aluno aluno = new Aluno();

                aluno.setIdPessoa(rs.getInt("id_pessoa"));
                aluno.setMatricula(rs.getString("matricula"));
                aluno.setStatusMatricula(
                        rs.getString("status_matricula")
                );

                lista.add(aluno);
            }

        } finally {
            fecharBanco();
        }

        return lista;
    }
}
