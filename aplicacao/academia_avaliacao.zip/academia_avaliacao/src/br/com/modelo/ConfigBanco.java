package br.com.modelo;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Ordem de busca: 1) variável de ambiente; 2) arquivo config.properties
 * (ou o caminho indicado na variável ACADEMIA_CONFIG).
 * O arquivo real NÃO é versionado (ver .gitignore).
 */
public final class ConfigBanco {

    private static final Properties PROPS = new Properties();

    static {
        String caminho = System.getenv("ACADEMIA_CONFIG");
        if (caminho == null || caminho.trim().isEmpty()) {
            caminho = "config.properties";
        }
        try (InputStream in = new FileInputStream(caminho)) {
            PROPS.load(in);
        } catch (IOException e) {
            System.err.println("Arquivo de configuração não encontrado: "
                    + caminho + " (usando apenas variáveis de ambiente).");
        }
    }

    private ConfigBanco() {
    }

    public static String obter(String chave, String variavelAmbiente) {
        String valor = System.getenv(variavelAmbiente);
        if (valor == null || valor.trim().isEmpty()) {
            valor = PROPS.getProperty(chave);
        }
        if (valor == null || valor.trim().isEmpty()) {
            throw new IllegalStateException(
                "Configuração ausente: '" + chave + "' (ou variável de ambiente "
                + variavelAmbiente + "). Copie config.properties.example para "
                + "config.properties e preencha.");
        }
        return valor.trim();
    }
}