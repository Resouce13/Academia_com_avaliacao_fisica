package br.com.modelo;

import br.com.controle.Treino;
import br.com.controle.TreinoExercicio;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.ArrayList;

public class TreinoDAO extends DAO {

    // =====================================================
    // 1. CADASTRAR TREINO COM EXERCICIOS
    // =====================================================
    public void criarTreinoComExercicios(
            Treino treino,
            ArrayList<TreinoExercicio> exercicios) throws Exception {

        try {
            abrirBanco();
            con.setAutoCommit(false);

            try {
                String sqlTreino
                        = "INSERT INTO treino "
                        + "(id_pessoa_aluno, nome_treino, status_treino) "
                        + "VALUES (?, ?, ?)";

                int idTreino;

                try (PreparedStatement pst = con.prepareStatement(
                        sqlTreino, PreparedStatement.RETURN_GENERATED_KEYS)) {

                    pst.setInt(1, treino.getIdPessoaAluno());
                    pst.setString(2, treino.getNomeTreino());
                    pst.setString(3, treino.getStatusTreino());

                    pst.executeUpdate();

                    try (ResultSet rs = pst.getGeneratedKeys()) {
                        if (!rs.next()) {
                            throw new SQLException(
                                    "Não foi possível obter o ID do treino.");
                        }

                        idTreino = rs.getInt(1);
                    }
                }

                String sqlPrescricao
                        = "INSERT INTO prescricao "
                        + "(id_pessoa_profissional, id_treino, data_prescricao) "
                        + "VALUES (?, ?, ?)";

                try (PreparedStatement pst = con.prepareStatement(sqlPrescricao)) {
                    pst.setInt(1, treino.getIdPessoaProfissional());
                    pst.setInt(2, idTreino);
                    pst.setString(3, treino.getDataPrescricao());
                    pst.executeUpdate();
                }

                inserirExercicios(idTreino, exercicios);

                con.commit();

            } catch (Exception e) {
                try {
                    con.rollback();
                } catch (SQLException erroRollback) {
                    e.addSuppressed(erroRollback);
                }
                throw e;

            } finally {
                try {
                    con.setAutoCommit(true);
                } catch (SQLException e) {
                    // A conexão será fechada abaixo.
                }
            }

        } finally {
            fecharBanco();
        }
    }

    // =====================================================
    // 2. INSERIR EXERCICIOS DO TREINO
    // =====================================================
    private void inserirExercicios(
            int idTreino,
            ArrayList<TreinoExercicio> exercicios) throws SQLException {

        String sql
                = "INSERT INTO treino_exercicio "
                + "(id_treino, id_exercicio, quantidade_series, "
                + "repeticoes, carga, tempo_descanso, ordem_execucao) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement pst = con.prepareStatement(sql)) {
            for (TreinoExercicio e : exercicios) {
                pst.setInt(1, idTreino);
                pst.setInt(2, e.getIdExercicio());
                pst.setInt(3, e.getQuantidadeSeries());
                pst.setInt(4, e.getRepeticoes());
                pst.setDouble(5, e.getCarga());
                pst.setInt(6, e.getTempoDescanso());
                pst.setInt(7, e.getOrdemExecucao());

                pst.executeUpdate();
            }
        }
    }

    // =====================================================
    // 3. CONSULTAR TODOS OS TREINOS
    // =====================================================
    public ArrayList<Object[]> consultarTreinos() throws Exception {

        ArrayList<Object[]> lista = new ArrayList<>();

        String sql
                = "SELECT t.id_treino, t.id_pessoa_aluno, "
                + "p.id_pessoa_profissional AS id_profissional, "
                + "p.data_prescricao, t.nome_treino, t.status_treino, "
                + "a.matricula AS matricula_aluno "
                + "FROM treino t "
                + "INNER JOIN aluno a "
                + "ON a.id_pessoa = t.id_pessoa_aluno "
                + "LEFT JOIN ("
                + "SELECT id_treino, "
                + "MIN(id_pessoa_profissional) AS id_pessoa_profissional, "
                + "MIN(data_prescricao) AS data_prescricao "
                + "FROM prescricao GROUP BY id_treino"
                + ") p ON p.id_treino = t.id_treino "
                + "ORDER BY t.id_treino";

        try {
            abrirBanco();

            try (PreparedStatement pst = con.prepareStatement(sql); ResultSet rs = pst.executeQuery()) {

                while (rs.next()) {
                    lista.add(new Object[]{
                        rs.getInt("id_treino"),
                        rs.getInt("id_pessoa_aluno"),
                        rs.getObject("id_profissional"),
                        rs.getDate("data_prescricao"),
                        rs.getString("nome_treino"),
                        rs.getString("status_treino"),
                        rs.getString("matricula_aluno")
                    });
                }
            }
        } finally {
            fecharBanco();
        }

        return lista;
    }

    // =====================================================
    // 4. CONSULTAR EXERCICIOS DE UM TREINO
    // =====================================================
    public ArrayList<TreinoExercicio> consultarExercicios(
            int idTreino) throws Exception {

        ArrayList<TreinoExercicio> lista = new ArrayList<>();

        String sql
                = "SELECT id_exercicio, quantidade_series, repeticoes, "
                + "carga, tempo_descanso, ordem_execucao "
                + "FROM treino_exercicio "
                + "WHERE id_treino = ? ORDER BY ordem_execucao";

        try {
            abrirBanco();

            try (PreparedStatement pst = con.prepareStatement(sql)) {
                pst.setInt(1, idTreino);

                try (ResultSet rs = pst.executeQuery()) {
                    while (rs.next()) {
                        TreinoExercicio e = new TreinoExercicio();

                        e.setIdExercicio(rs.getInt("id_exercicio"));
                        e.setQuantidadeSeries(
                                rs.getInt("quantidade_series"));
                        e.setRepeticoes(rs.getInt("repeticoes"));
                        e.setCarga(rs.getDouble("carga"));
                        e.setTempoDescanso(
                                rs.getInt("tempo_descanso"));
                        e.setOrdemExecucao(
                                rs.getInt("ordem_execucao"));

                        lista.add(e);
                    }
                }
            }
        } finally {
            fecharBanco();
        }

        return lista;
    }

    // =====================================================
    // 5. ALTERAR TREINO E SEUS EXERCICIOS
    // =====================================================
    public void alterarTreinoComExercicios(
            Treino treino,
            ArrayList<TreinoExercicio> exercicios) throws Exception {

        try {
            abrirBanco();
            con.setAutoCommit(false);

            try {
                String sqlTreino
                        = "UPDATE treino SET id_pessoa_aluno = ?, "
                        + "nome_treino = ?, status_treino = ? "
                        + "WHERE id_treino = ?";

                try (PreparedStatement pst = con.prepareStatement(sqlTreino)) {
                    pst.setInt(1, treino.getIdPessoaAluno());
                    pst.setString(2, treino.getNomeTreino());
                    pst.setString(3, treino.getStatusTreino());
                    pst.setInt(4, treino.getIdTreino());

                    if (pst.executeUpdate() == 0) {
                        throw new SQLException("Treino não encontrado.");
                    }
                }

                String excluirPrescricao
                        = "DELETE FROM prescricao WHERE id_treino = ?";

                try (PreparedStatement pst = con.prepareStatement(excluirPrescricao)) {
                    pst.setInt(1, treino.getIdTreino());
                    pst.executeUpdate();
                }

                String inserirPrescricao
                        = "INSERT INTO prescricao "
                        + "(id_pessoa_profissional, id_treino, data_prescricao) "
                        + "VALUES (?, ?, ?)";

                try (PreparedStatement pst = con.prepareStatement(inserirPrescricao)) {
                    pst.setInt(1, treino.getIdPessoaProfissional());
                    pst.setInt(2, treino.getIdTreino());
                    pst.setString(3, treino.getDataPrescricao());
                    pst.executeUpdate();
                }

                String excluirExercicios
                        = "DELETE FROM treino_exercicio WHERE id_treino = ?";

                try (PreparedStatement pst = con.prepareStatement(excluirExercicios)) {
                    pst.setInt(1, treino.getIdTreino());
                    pst.executeUpdate();
                }

                inserirExercicios(treino.getIdTreino(), exercicios);

                con.commit();

            } catch (Exception e) {
                try {
                    con.rollback();
                } catch (SQLException erroRollback) {
                    e.addSuppressed(erroRollback);
                }
                throw e;

            } finally {
                try {
                    con.setAutoCommit(true);
                } catch (SQLException e) {
                    // A conexão será fechada abaixo.
                }
            }

        } finally {
            fecharBanco();
        }
    }

    // =====================================================
    // 6. EXCLUIR TREINO E SEUS RELACIONAMENTOS
    // =====================================================
    public void excluirTreino(int idTreino) throws Exception {

        try {
            abrirBanco();
            con.setAutoCommit(false);

            try {
                String sqlExercicios
                        = "DELETE FROM treino_exercicio WHERE id_treino = ?";

                try (PreparedStatement pst = con.prepareStatement(sqlExercicios)) {
                    pst.setInt(1, idTreino);
                    pst.executeUpdate();
                }

                String sqlPrescricao
                        = "DELETE FROM prescricao WHERE id_treino = ?";

                try (PreparedStatement pst = con.prepareStatement(sqlPrescricao)) {
                    pst.setInt(1, idTreino);
                    pst.executeUpdate();
                }

                String sqlTreino
                        = "DELETE FROM treino WHERE id_treino = ?";

                try (PreparedStatement pst = con.prepareStatement(sqlTreino)) {
                    pst.setInt(1, idTreino);

                    if (pst.executeUpdate() == 0) {
                        throw new SQLException("Treino não encontrado.");
                    }
                }

                con.commit();

            } catch (Exception e) {
                try {
                    con.rollback();
                } catch (SQLException erroRollback) {
                    e.addSuppressed(erroRollback);
                }
                throw e;

            } finally {
                try {
                    con.setAutoCommit(true);
                } catch (SQLException e) {
                    // A conexão será fechada abaixo.
                }
            }

        } finally {
            fecharBanco();
        }
    }

    // =====================================================
    // 7. CONSULTAR TREINOS DE UM ALUNO
    // =====================================================
    public ArrayList<Object[]> consultarTreinosPorAluno(
            int idAluno) throws Exception {

        ArrayList<Object[]> lista = new ArrayList<>();

        String sql
                = "SELECT t.id_treino, t.id_pessoa_aluno, "
                + "p.id_pessoa_profissional AS id_profissional, "
                + "p.data_prescricao, t.nome_treino, t.status_treino, "
                + "a.matricula AS matricula_aluno "
                + "FROM treino t "
                + "INNER JOIN aluno a "
                + "ON a.id_pessoa = t.id_pessoa_aluno "
                + "LEFT JOIN ("
                + "SELECT id_treino, "
                + "MIN(id_pessoa_profissional) AS id_pessoa_profissional, "
                + "MIN(data_prescricao) AS data_prescricao "
                + "FROM prescricao GROUP BY id_treino"
                + ") p ON p.id_treino = t.id_treino "
                + "WHERE t.id_pessoa_aluno = ? "
                + "ORDER BY t.id_treino";

        try {
            abrirBanco();

            try (PreparedStatement pst = con.prepareStatement(sql)) {
                pst.setInt(1, idAluno);

                try (ResultSet rs = pst.executeQuery()) {
                    while (rs.next()) {
                        lista.add(new Object[]{
                            rs.getInt("id_treino"),
                            rs.getInt("id_pessoa_aluno"),
                            rs.getObject("id_profissional"),
                            rs.getDate("data_prescricao"),
                            rs.getString("nome_treino"),
                            rs.getString("status_treino"),
                            rs.getString("matricula_aluno")
                        });
                    }
                }
            }
        } finally {
            fecharBanco();
        }

        return lista;
    }

}
