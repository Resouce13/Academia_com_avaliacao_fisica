# Evolução do modelo desde a Etapa 1

## Ponto de partida
A Etapa 1 possuía `pessoa`, `aluno`, `profissional`, `plano`, `contrato`, `avaliacao_fisica`, `medida`, `treino`, `prescricao`, `exercicio` e `treino_exercicio`, além de restrições, índices e 15 consultas de verificação.

## Evoluções identificadas no desenvolvimento
- As consultas SQL foram modificadas e ampliadas.
- A carga de dados foi ampliada para testes com maior volume.
- Foi desenvolvida uma aplicação Java Swing conectada ao MySQL.
- Foram trabalhadas consultas parametrizadas, relatório por view, transações, perfis de acesso e otimização com `EXPLAIN`.

## Diferenças estruturais a confirmar
A equipe relatou criação/alteração de tabelas após a Etapa 1. Compare o DDL inicial com o DDL final antes de preencher os nomes exatos.

| Item | Etapa 1 | Versão final | Evidência |
|---|---|---|---|
| Tabelas adicionadas | Comparar scripts | A confirmar | DDL inicial/final |
| Colunas alteradas | Comparar scripts | A confirmar | `SHOW CREATE TABLE` |
| Índices adicionados | Havia índices no DDL inicial | A confirmar | DDL e estudos B4 |
| Views | Consultas de verificação | A confirmar | Script de views |
| Auditoria | A confirmar | A confirmar após execução | Script e consulta à auditoria |

Registre somente diferenças confirmadas e vincule cada uma a um arquivo ou evidência.
