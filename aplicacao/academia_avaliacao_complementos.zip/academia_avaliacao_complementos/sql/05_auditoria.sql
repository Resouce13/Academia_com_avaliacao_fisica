-- Auditoria de UPDATE em treino e contrato — MySQL 8.0+
-- Teste primeiro em uma cópia do banco.
USE academia_avaliacao;

CREATE TABLE IF NOT EXISTS auditoria_eventos (
    id_auditoria BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    tabela_afetada VARCHAR(64) NOT NULL,
    operacao VARCHAR(10) NOT NULL,
    chave_registro VARCHAR(100) NOT NULL,
    autor VARCHAR(288) NOT NULL,
    data_evento TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    valores_antigos JSON NOT NULL,
    valores_novos JSON NOT NULL,
    CONSTRAINT pk_auditoria_eventos PRIMARY KEY (id_auditoria),
    INDEX idx_auditoria_tabela_data (tabela_afetada, data_evento),
    INDEX idx_auditoria_autor_data (autor, data_evento)
) ENGINE = InnoDB;

-- Remove somente gatilhos com estes nomes, caso sejam versões anteriores deste arquivo.
DROP TRIGGER IF EXISTS trg_auditoria_treino_update;
DROP TRIGGER IF EXISTS trg_auditoria_contrato_update;

DELIMITER $$
CREATE TRIGGER trg_auditoria_treino_update AFTER UPDATE ON treino
FOR EACH ROW
BEGIN
    INSERT INTO auditoria_eventos
      (tabela_afetada, operacao, chave_registro, autor, valores_antigos, valores_novos)
    VALUES
      ('treino', 'UPDATE', CAST(OLD.id_treino AS CHAR),
       COALESCE(NULLIF(@usuario_aplicacao, ''), CURRENT_USER()),
       JSON_OBJECT('id_treino', OLD.id_treino, 'id_pessoa_aluno', OLD.id_pessoa_aluno,
                   'nome_treino', OLD.nome_treino, 'status_treino', OLD.status_treino),
       JSON_OBJECT('id_treino', NEW.id_treino, 'id_pessoa_aluno', NEW.id_pessoa_aluno,
                   'nome_treino', NEW.nome_treino, 'status_treino', NEW.status_treino));
END$$

CREATE TRIGGER trg_auditoria_contrato_update AFTER UPDATE ON contrato
FOR EACH ROW
BEGIN
    INSERT INTO auditoria_eventos
      (tabela_afetada, operacao, chave_registro, autor, valores_antigos, valores_novos)
    VALUES
      ('contrato', 'UPDATE', CAST(OLD.id_contrato AS CHAR),
       COALESCE(NULLIF(@usuario_aplicacao, ''), CURRENT_USER()),
       JSON_OBJECT('id_contrato', OLD.id_contrato, 'id_pessoa_aluno', OLD.id_pessoa_aluno,
                   'id_plano', OLD.id_plano, 'data_inicio', OLD.data_inicio,
                   'data_termino', OLD.data_termino, 'situacao', OLD.situacao),
       JSON_OBJECT('id_contrato', NEW.id_contrato, 'id_pessoa_aluno', NEW.id_pessoa_aluno,
                   'id_plano', NEW.id_plano, 'data_inicio', NEW.data_inicio,
                   'data_termino', NEW.data_termino, 'situacao', NEW.situacao));
END$$
DELIMITER ;

-- Teste em banco de desenvolvimento:
-- SET @usuario_aplicacao = 'teste_local';
-- UPDATE treino SET nome_treino = CONCAT(nome_treino, ' - teste auditoria') WHERE id_treino = 1;
-- SELECT * FROM auditoria_eventos ORDER BY id_auditoria DESC LIMIT 5;
-- A variável @usuario_aplicacao só é confiável se a aplicação controlar a sessão.
-- Caso não seja definida, CURRENT_USER() registra a conta MySQL efetiva.
