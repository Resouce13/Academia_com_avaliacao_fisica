# Complementos — Academia com Avaliação Física

Arquivos de apoio para revisar a Etapa 2. Não execute tudo de uma vez: faça backup e teste em uma cópia do banco.

- `sql/04_roles_acesso.sql`: três perfis de acesso e view restrita.
- `sql/05_auditoria.sql`: tabela de auditoria e dois gatilhos.
- `sql/06_usuario_app.sql`: estrutura para credenciais com hash e sal.
- `java/SenhaUtil.java`: utilitário Java PBKDF2-HMAC-SHA256.
- `docs/experimento_concorrencia.md`: roteiro de teste com duas sessões.
- `docs/plano_backup.md`: estratégia de backup e restauração.
- `docs/teste_injecao_sql.md`: roteiro de teste de injeção SQL.
- `docs/evolucao_modelo.md`: modelo de comparação com a Etapa 1.
- `docs/checklist_final.md`: checklist de verificação.

**Importante:** estes arquivos são complementos preparados a partir do esquema conhecido; não provam que os testes foram executados. A tabela de usuários e `SenhaUtil.java` ainda precisam ser integrados à aplicação. Não versione senhas, `.env`, credenciais nem dumps com dados pessoais.
