/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.modelo;

/**
 *
 * @author Gabriel_DEV
 */
import br.com.controle.Profissional;

public class TestProfissional {

    public static void main(String[] args) throws Exception {

        Profissional p = new Profissional();

        p.setIdPessoa(3);
        p.setRegistroProfissional("CREF099999GDF");
        p.setEspecialidade("Musculação");
        p.setIdSupervisor(1);

        ProfissionalDAO dao = new ProfissionalDAO();

        dao.inserir(p);

        System.out.println("Teste concluído!");
    }
}