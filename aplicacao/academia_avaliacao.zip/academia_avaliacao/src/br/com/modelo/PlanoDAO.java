/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.modelo;

/**
 *
 * @author Gabriel_DEV
 */
import br.com.controle.Plano;
import java.util.ArrayList;

public class PlanoDAO extends DAO {

    // =========================
    // CRIAR
    // =========================
    public void inserir(Plano p) throws Exception {

        try {
            abrirBanco();

            String query = "INSERT INTO plano "
                    + "(nome_plano, valor_mensal, duracao_meses) "
                    + "VALUES (?, ?, ?)";

            pst = con.prepareStatement(query);

            pst.setString(1, p.getNomePlano());
            pst.setFloat(2, p.getValorMensal());
            pst.setInt(3, p.getDuracaoMeses());

            pst.executeUpdate();

        } finally {
            fecharBanco();
        }
    }

    // =========================
    // CONSULTAR
    // =========================
    public ArrayList<Plano> listar() throws Exception {

        ArrayList<Plano> lista = new ArrayList<>();

        try {
            abrirBanco();

            String query = "SELECT id_plano, "
                    + "nome_plano, valor_mensal, duracao_meses "
                    + "FROM plano "
                    + "ORDER BY nome_plano";

            pst = con.prepareStatement(query);

            rs = pst.executeQuery();

            while (rs.next()) {

                Plano p = new Plano();

                p.setIdPlano(rs.getInt("id_plano"));
                p.setNomePlano(rs.getString("nome_plano"));
                p.setValorMensal(rs.getFloat("valor_mensal"));
                p.setDuracaoMeses(rs.getInt("duracao_meses"));

                lista.add(p);
            }

        } finally {
            fecharBanco();
        }

        return lista;
    }

    // =========================
    // ALTERAR
    // =========================
    public void alterar(Plano p) throws Exception {

        try {
            abrirBanco();

            String query = "UPDATE plano "
                    + "SET nome_plano = ?, "
                    + "valor_mensal = ?, "
                    + "duracao_meses = ? "
                    + "WHERE id_plano = ?";

            pst = con.prepareStatement(query);

            pst.setString(1, p.getNomePlano());
            pst.setFloat(2, p.getValorMensal());
            pst.setInt(3, p.getDuracaoMeses());
            pst.setInt(4, p.getIdPlano());

            pst.executeUpdate();

        } finally {
            fecharBanco();
        }
    }

    // =========================
    // EXCLUIR
    // =========================
    public void excluir(int id) throws Exception {

        try {
            abrirBanco();

            String query = "DELETE FROM plano "
                    + "WHERE id_plano = ?";

            pst = con.prepareStatement(query);

            pst.setInt(1, id);

            pst.executeUpdate();

        } finally {
            fecharBanco();
        }
    }
    // CONSULTAR PLANOS PELO NOME

    public ArrayList<Plano> consultarPorNome(String nome) throws Exception {

        ArrayList<Plano> lista = new ArrayList<>();

        try {
            abrirBanco();

            String query
                    = "SELECT id_plano, nome_plano, valor_mensal, duracao_meses "
                    + "FROM plano "
                    + "WHERE nome_plano LIKE ? "
                    + "ORDER BY nome_plano";

            pst = con.prepareStatement(query);
            pst.setString(1, "%" + nome + "%");

            rs = pst.executeQuery();

            while (rs.next()) {
                Plano p = new Plano();

                p.setIdPlano(rs.getInt("id_plano"));
                p.setNomePlano(rs.getString("nome_plano"));
                p.setValorMensal(rs.getFloat("valor_mensal"));
                p.setDuracaoMeses(rs.getInt("duracao_meses"));

                lista.add(p);
            }

        } finally {
            fecharBanco();
        }

        return lista;
    }
}
