
package br.com.modelo;

public class TesteCadastroUsuario {

    public static void main(String[] args) {
        UsuarioAplicacaoDAO dao = new UsuarioAplicacaoDAO();

        try {
            boolean cadastrado = dao.cadastrarUsuario(
                "usuario_teste_b5",
                "SenhaForte@2026",
                "CONSULTA"
            );

            if (cadastrado) {
                System.out.println("Usuário cadastrado com sucesso!");
            }

        } catch (Exception e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }
}