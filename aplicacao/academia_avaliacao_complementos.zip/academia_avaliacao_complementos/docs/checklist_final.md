# Checklist final da Etapa 2

Marque cada item somente depois de executar ou conferir a evidência.

## Aplicação
- [ ] Quatro CRUDs completos.
- [ ] Duas consultas parametrizadas com filtro e junção/agregação.
- [ ] Relatório por view.
- [ ] Erros de restrição em mensagens amigáveis.
- [ ] Teste de injeção SQL executado e documentado.
- [ ] Credenciais fora do código e do Git.

## Transações e concorrência
- [ ] Transação em múltiplas tabelas testada com sucesso.
- [ ] Falha provocada e `ROLLBACK` confirmado.
- [ ] Integridade conferida após falha.
- [ ] Duas sessões simultâneas testadas.
- [ ] Isolamento observado e justificado.

## Otimização
- [ ] Três estudos com plano antes, índice, plano depois e tempo.
- [ ] Volume de dados e condições do teste registrados.
- [ ] Resultado sem ganho também documentado, se ocorrer.

## Segurança e auditoria
- [ ] Três perfis testados com logins distintos.
- [ ] Privilégios conferidos com `SHOW GRANTS`.
- [ ] Perfil de consulta acessa view restrita e não tabelas-base.
- [ ] Hash e sal integrados e testados na aplicação.
- [ ] Dois gatilhos de auditoria criados.
- [ ] Autor, data e valores anteriores/novos conferidos.

## Projeto físico e documentação
- [ ] Backup lógico gerado.
- [ ] Restauração testada em banco separado.
- [ ] Retenção documentada.
- [ ] DDL final comparado com Etapa 1.
- [ ] Correções da devolutiva descritas com evidências.
- [ ] PDF consolidado e paginado.
- [ ] Declaração de uso de IA preenchida conforme orientação do professor.

## Demonstração
- [ ] Banco populado e aplicação testada.
- [ ] Duas sessões MySQL abertas.
- [ ] Roteiro ensaiado para 15 minutos.
- [ ] Cada integrante sabe explicar o modelo e os testes.
