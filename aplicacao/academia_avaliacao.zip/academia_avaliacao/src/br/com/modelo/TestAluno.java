/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.modelo;

/**
 *
 * @author Gabriel_DEV
 */
import br.com.controle.Aluno;

public class TestAluno {

    public static void main(String[] args) throws Exception {

        Aluno a = new Aluno();

        a.setIdPessoa(1);
        a.setMatricula("ALU001");
        a.setStatusMatricula("ativa");

        AlunoDAO dao = new AlunoDAO();

        dao.inserir(a);

        System.out.println("Teste concluído!");
    }
}