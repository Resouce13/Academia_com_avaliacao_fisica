-- Perfis de acesso — MySQL 8.0+
USE academia_avaliacao;

-- View restrita: não expõe CPF, endereço, telefone ou e-mail.
CREATE OR REPLACE VIEW vw_alunos_consulta AS
SELECT p.nome, a.matricula, a.status_matricula
FROM aluno a JOIN pessoa p ON p.id_pessoa = a.id_pessoa;

CREATE ROLE IF NOT EXISTS 'role_admin';
CREATE ROLE IF NOT EXISTS 'role_funcionario';
CREATE ROLE IF NOT EXISTS 'role_consulta';

-- Administrador da aplicação: CRUD de dados, sem privilégios globais do servidor.
GRANT SELECT, INSERT, UPDATE, DELETE ON academia_avaliacao.* TO 'role_admin';

-- Funcionário: pode consultar, inserir e alterar; não pode excluir.
GRANT SELECT, INSERT, UPDATE ON academia_avaliacao.pessoa TO 'role_funcionario';
GRANT SELECT, INSERT, UPDATE ON academia_avaliacao.aluno TO 'role_funcionario';
GRANT SELECT, INSERT, UPDATE ON academia_avaliacao.profissional TO 'role_funcionario';
GRANT SELECT, INSERT, UPDATE ON academia_avaliacao.plano TO 'role_funcionario';
GRANT SELECT, INSERT, UPDATE ON academia_avaliacao.contrato TO 'role_funcionario';
GRANT SELECT, INSERT, UPDATE ON academia_avaliacao.avaliacao_fisica TO 'role_funcionario';
GRANT SELECT, INSERT, UPDATE ON academia_avaliacao.medida TO 'role_funcionario';
GRANT SELECT, INSERT, UPDATE ON academia_avaliacao.treino TO 'role_funcionario';
GRANT SELECT, INSERT, UPDATE ON academia_avaliacao.prescricao TO 'role_funcionario';
GRANT SELECT, INSERT, UPDATE ON academia_avaliacao.exercicio TO 'role_funcionario';
GRANT SELECT, INSERT, UPDATE ON academia_avaliacao.treino_exercicio TO 'role_funcionario';

-- Consulta: somente a view restrita.
GRANT SELECT ON academia_avaliacao.vw_alunos_consulta TO 'role_consulta';

SHOW GRANTS FOR 'role_admin';
SHOW GRANTS FOR 'role_funcionario';
SHOW GRANTS FOR 'role_consulta';

-- Este script cria roles, não usuários reais. Crie usuários locais com senhas fortes,
-- conceda a role apropriada e teste cada usuário em conexão separada.
-- Não salve senhas reais neste repositório.
-- Teste como role_consulta:
-- SET ROLE 'role_consulta';
-- SELECT * FROM academia_avaliacao.vw_alunos_consulta; -- deve funcionar
-- SELECT * FROM academia_avaliacao.pessoa; -- deve ser negado
