/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.modelo;

/**
 *
 * @author Gabriel_DEV
 */
import br.com.controle.Exercicio;
import java.util.ArrayList;

public class ExercicioDAO extends DAO {

    // =========================
    // CRIAR
    // =========================
    public void inserir(Exercicio e) throws Exception {

        try {
            abrirBanco();

            String query = "INSERT INTO exercicio "
                    + "(nome_exercicio, grupo_muscular) "
                    + "VALUES (?, ?)";

            pst = con.prepareStatement(query);

            pst.setString(1, e.getNomeExercicio());
            pst.setString(2, e.getGrupoMuscular());

            pst.executeUpdate();

        } finally {
            fecharBanco();
        }
    }

    // =========================
    // CONSULTAR
    // =========================
    public ArrayList<Exercicio> listar() throws Exception {

        ArrayList<Exercicio> lista = new ArrayList<>();

        try {
            abrirBanco();

            String query = "SELECT id_exercicio, "
                    + "nome_exercicio, grupo_muscular "
                    + "FROM exercicio "
                    + "ORDER BY nome_exercicio";

            pst = con.prepareStatement(query);

            rs = pst.executeQuery();

            while (rs.next()) {

                Exercicio e = new Exercicio();

                e.setIdExercicio(rs.getInt("id_exercicio"));
                e.setNomeExercicio(rs.getString("nome_exercicio"));
                e.setGrupoMuscular(rs.getString("grupo_muscular"));

                lista.add(e);
            }

        } finally {
            fecharBanco();
        }

        return lista;
    }

    // =========================
    // ALTERAR
    // =========================
    public void alterar(Exercicio e) throws Exception {

        try {
            abrirBanco();

            String query = "UPDATE exercicio "
                    + "SET nome_exercicio = ?, "
                    + "grupo_muscular = ? "
                    + "WHERE id_exercicio = ?";

            pst = con.prepareStatement(query);

            pst.setString(1, e.getNomeExercicio());
            pst.setString(2, e.getGrupoMuscular());
            pst.setInt(3, e.getIdExercicio());

            pst.executeUpdate();

        } finally {
            fecharBanco();
        }
    }

    // =========================
    // EXCLUIR
    // =========================
    public void excluir(int id) throws Exception {

        try {
            abrirBanco();

            String query = "DELETE FROM exercicio "
                    + "WHERE id_exercicio = ?";

            pst = con.prepareStatement(query);

            pst.setInt(1, id);

            pst.executeUpdate();

        } finally {
            fecharBanco();
        }
    }
}
