# Teste de resistência à injeção de SQL

## Exemplo de consulta parametrizada
Adapte ao método real da aplicação:

```java
String sql = "SELECT id_exercicio, nome_exercicio, grupo_muscular "
           + "FROM exercicio WHERE grupo_muscular = ?";
PreparedStatement pst = con.prepareStatement(sql);
pst.setString(1, grupoMuscularInformado);
ResultSet rs = pst.executeQuery();
```

## Teste manual
1. Abra uma tela que filtre por texto.
2. Execute uma busca normal e registre o resultado.
3. No mesmo campo, teste a entrada: `' OR '1'='1' -- `
4. Observe se ela é tratada como valor de pesquisa, sem alterar a estrutura da consulta.
5. Registre a entrada exata, tela/método e resultado real.
6. Repita nos outros campos de consulta com entrada textual.

## Evidência
Inclua captura da entrada e resultado, além do trecho real com `PreparedStatement` e setters. A entrada não deve alterar a lógica SQL nem executar comandos adicionais. Pode retornar zero resultados ou uma busca literal, dependendo da consulta.

Não declare o teste aprovado até executá-lo na aplicação final. Revise também se alguma consulta concatena entradas do usuário.
